/* */ 
"format cjs";
require('./angular-mocks');
module.exports = 'ngAnimateMock';
