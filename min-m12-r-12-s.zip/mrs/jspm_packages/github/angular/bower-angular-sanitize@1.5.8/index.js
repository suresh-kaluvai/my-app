/* */ 
"format cjs";
require('./angular-sanitize');
module.exports = 'ngSanitize';
