/*
  Example: Whatever gets imported / exported from here will become available to an installed library
*/
import * as angular from 'angular';
// yeoman: imports

const deps = [
  // yeoman: dep
];

angular.module('<%= prefix %>', deps);

export {
    // yeoman: exports
};