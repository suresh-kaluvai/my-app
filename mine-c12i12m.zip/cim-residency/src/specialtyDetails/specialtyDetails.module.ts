import {module} from 'angular'; 
import SpecialtyDetailsComponent from './specialtyDetails.component';

let SpecialtyDetailsModule = module('specialtyDetails', [])
.component('specialtyDetails', SpecialtyDetailsComponent);

export default SpecialtyDetailsModule;
