import template from './specialtyDetails.component.html';

export class SpecialtyDetailsController {
  constructor() {

  }
}

const SpecialtyDetailsComponent = {
  template,
  controller: SpecialtyDetailsController,
  controllerAs: 'specialtyDetails'
};

export default SpecialtyDetailsComponent;
