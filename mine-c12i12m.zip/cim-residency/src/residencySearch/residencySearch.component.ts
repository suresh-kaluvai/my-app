import * as angular from 'angular';
import template from './residencySearch.component.html';
import * as _ from 'lodash';

export class ResidencySearchController {
    private programs: any;
    private sortFields: any;
    private count: any;
    private options: any;
    private change: any;
    private clearFilters: any;
    private tags: any;
    private view: any;
    private pipeFunction: any;
    private sortField: any;
    private filterData: any;
    private textFormatService: any;
    private userRolesService: any;
    private user: any;
    private securityService: any;
    private loggedIn: any;
    private rowCount: any;
    private rowStartIndex: any;
    private useServiceStartIndex: any;
    private searchKeyword: any;
    private filterTagData: any;
    private tagCities: Object[];
    private tagStates: String[];
    private tagSpecialties: String[];

    constructor(mockdataService, private $scope, searchResultsService, textFormatService, userRolesService, securityService) {
        let vm = this;
        vm.$scope = $scope;
        vm.textFormatService = textFormatService;
        vm.securityService = securityService;
        vm.userRolesService = userRolesService;

        // vm.isUserLoggedIn = securityService.isUserLoggedIn();
        // console.log(vm.isUserLoggedIn);
        vm.programs = [];

        this.view = "List";


        this.clearFilters = function () {
            this.tags = [];
            this.filtering.by = {};
            this.filtering.by.appDeadline = {};
            //this.filtering.by = angular.copy(defaultFilterJson);
        };

        vm.sortField = vm.textFormatService.sortField;
        vm.rowCount = vm.textFormatService.rowCount;
        vm.rowStartIndex = vm.textFormatService.rowStartIndex;
        vm.useServiceStartIndex = true;

        this.sortFields = [
            {
                label: 'Location A-Z',
                value: 'state,asc'
            }, {
                label: 'Location Z-A',
                value: 'state,desc'
            },
            {
                label: 'Program Name A-Z',
                value: 'programName,asc'
            }, {
                label: 'Program Name Z-A',
                value: 'programName,desc'
            }, {
                label: 'Specialty A-Z',
                value: 'specialtyName,asc'
            }, {
                label: 'Specialty Z-A',
                value: 'specialtyName,desc'
            }
        ];

        vm.textFormatService.getSearchResult = vm.getSearchResult.bind(vm);
        vm.textFormatService.resetSortDisplay = vm.resetSortDisplay.bind(vm);

        vm.loggedIn = vm.isUserLoggedIn();

        $scope.$watch('residencySearch.securityService.isUserLoggedIn()', function (val) {
            if (val === true) {
                vm.user = vm.roles();
            } else {
                vm.user = {
                    isMD: false,
                    isDO: false,
                    isAdmin: false,
                    isGuest: true,
                    isMultiRoleUser: false,
                    isInvalidUser: false
                };
            }
        });

        $scope.pipeFunction = function (params) {
            vm.filterData = textFormatService.filterData;
            vm.setTagsData();
           
            var p = params.pagination;
            var sort = params.pagination.sort;
            var f = _.extend({
                sort: params.pagination.sort || 'programName',
            }, params.search.predicateObject);
            
            
            // To persist the row count between the search page and detail page.
            p.number = vm.rowCount;
            p.start = (vm.useServiceStartIndex ? vm.rowStartIndex : p.start);
            f.size = p.number;
            f.page = (p.start / p.number);
            f.sort = vm.sortField;

            // storing the row count every search
            vm.textFormatService.rowCount = vm.rowCount;
            vm.textFormatService.rowStartIndex = p.start;
            vm.useServiceStartIndex = false;

            if (vm.searchKeyword) {
                f.searchKeyword = vm.searchKeyword;
                vm.textFormatService.searchKeyword = vm.searchKeyword;
            }

            if(f.searchKeyword && vm.textFormatService.searchKeyword) {
                let programType = vm.textFormatService.filterData.programType;

                return searchResultsService.getKeywordSearchResults(f, programType).then(function (data) {
                    p.totalItemCount = data.totalElements || 0;
                    p.numberOfPages = data.totalPages;
                    vm.programs = data.content || [];
                    vm.programs = vm.programs.slice(0);
                });
            } else if(!vm.textFormatService.searchKeyword) { 
                 vm.searchKeyword = '';
                return searchResultsService.getSearchResults(vm.filterData, f).then(function (data) {
                    p.totalItemCount = data.totalElements || 0;
                    p.numberOfPages = data.totalPages;
                    vm.programs = data.content || [];
                    vm.programs = vm.programs.slice(0);
                });
            }
        }

        vm.searchKeyword = vm.textFormatService.searchKeyword;

        this.tags = [];
    }

    $OnInit() {
        let vm = this;
        vm.filterTagData = vm.textFormatService.filterData;
    }

    isUserLoggedIn() {
        let vm = this;
        return vm.securityService.isUserLoggedIn();
    }
    context() {
        let vm = this;
        if (vm.isUserLoggedIn()) {
            return vm.securityService.context;
        }
    }

    roles() {
        let vm = this;
        if (vm.context()) {
            return vm.userRolesService.getRoles(vm.context());
        }
    }

    getSearchResult() {
        let vm = this;
        let tableState = vm.$scope.cimTable.stTable.tableState();
        vm.$scope.pipeFunction(tableState);
    }

    clearAllFilters() {
        let vm = this;
        vm.textFormatService.filterData.specialtyCds = [];
        vm.textFormatService.filterData.stateCds = [];
        vm.textFormatService.filterData.cities = [];
        vm.getSearchResult();
    }

    resetSortDisplay() {
        let vm = this;

        var tableState = vm.$scope.cimTable.stTable.tableState();
        tableState.pagination.sort = 'programName,asc';
        vm.sortField = 'programName,asc'
        vm.textFormatService.sortField =  vm.sortField;
        vm.rowCount = 10;
    }

    getSortResult() {
        let vm = this;
        var tableState = vm.$scope.cimTable.stTable.tableState();
        tableState.pagination.sort = vm.sortField;
        vm.textFormatService.sortField = vm.sortField;
        vm.rowCount = 10;
        vm.$scope.pipeFunction(tableState);
    }

    getKeywordSearch() {
        let vm = this;
        //vm.textFormatService.clearFilters();
        vm.filterData.stateCds = [];
        vm.filterData.cities = [];
        vm.filterData.specialtyCds = [];
        vm.textFormatService.filterData = vm.filterData;
        vm.textFormatService.clearFiltersNotGetResult();

        let tableState = vm.$scope.cimTable.stTable.tableState();
        tableState.pagination.sort = 'programName,asc';
        vm.sortField = 'programName,asc'
        tableState.search = {
            predicateObject: {
                searchKeyword: vm.searchKeyword
            }
        };

        vm.textFormatService.searchKeyword = vm.searchKeyword;
        vm.$scope.pipeFunction(tableState);
    }

    clearKeywordSearch() {
        let vm = this;
        vm.searchKeyword = '';
        vm.textFormatService.searchKeyword = '';
        let tableState = vm.$scope.cimTable.stTable.tableState();
        tableState.search = '';
        vm.getSearchResult();
    }

    setSearchKey() {
        let vm = this;
        vm.textFormatService.searchKeyword && vm.getKeywordSearch();
    }

    getTagCities(stateCitiesObj) {
        let vm = this;
        vm.tagCities =[];

        if(stateCitiesObj.length) {
            for(let i=0; i<stateCitiesObj.length; i++) {

                for(let j=0; j < stateCitiesObj[i].cities.length; j++) {
                    vm.tagCities.push(
                        {
                            'stateCd': stateCitiesObj[i].stateCd,
                            'city': stateCitiesObj[i].cities[j]
                        }
                    );
                }
            }

            vm.tagCities;
        }
    }

    setTagsData() {
        let vm = this;
        vm.tagSpecialties = angular.copy(vm.textFormatService.filterData.specialtyCds);
        vm.tagStates = angular.copy(vm.textFormatService.filterData.stateCds);
        vm.getTagCities(vm.textFormatService.filterData.cities);
    }

    getRefSpecialtyNameByCode(specialtyCd, isRemove=false) {
        let vm = this;
        let specialtyName: String = '';
        let specialtyList = vm.textFormatService.refSpecialtiesList;

        for(let i=0; i<specialtyList.length; i++) {
            if(specialtyList[i].parentSpecialty && 
            specialtyList[i].parentSpecialty.specialtyCd === specialtyCd) {
                specialtyName = specialtyList[i].parentSpecialty.specialtyName;
                if(isRemove) {
                    specialtyList[i].parentSpecialty.selected = false;
                    vm.textFormatService.setRuntimeSpecialtyCount(false);
                }
                break;
            }

            if(specialtyList[i].childSpecialties &&
                specialtyList[i].childSpecialties.length) {
                let childObj = specialtyList[i].childSpecialties;
                for(let j=0; j<childObj.length; j++) {
                    if(childObj[j] && (childObj[j].specialtyCd === specialtyCd)) {
                        specialtyName = childObj[j].specialtyName;
                        if(isRemove) {
                            childObj[j].selected = false;
                            vm.textFormatService.setRuntimeSpecialtyCount(false);
                        }
                        break;
                    }
                }
            }

            if(specialtyName) {
                break;
            }
        }

        if(isRemove) {
            vm.textFormatService.applyFilters();
            return '';
        } else {
            return specialtyName;
        }
    }

    removeStateTag(stateCd) {
        let vm = this;
        let stateArr = vm.textFormatService.stateList;
        for(let i=0; i<stateArr.length; i++) {
            if(stateArr[i].stateCd === stateCd) {
                stateArr[i].selected = false;
                vm.textFormatService.applyFilters();
                break;
            }
        }
    }

    removeCityTag(city) {
        let vm = this;
        let cityArr = vm.textFormatService.cityList;

        for(let i=0; i<cityArr.length; i++) {
            if(cityArr[i].city === city) {
                cityArr[i].selected = false;
                vm.textFormatService.applyFilters();
                break;
            }
        }
    }

    clearAllTags() {
        let vm = this;
        let specialtyList = vm.textFormatService.refSpecialtiesList;

        for(let i=0; i<specialtyList.length; i++) {
            if(specialtyList[i].parentSpecialty) {
                specialtyList[i].parentSpecialty.selected = false;
                vm.textFormatService.setRuntimeSpecialtyCount(false);
            }

            if(specialtyList[i].childSpecialties &&
                specialtyList[i].childSpecialties.length) {
                let childObj = specialtyList[i].childSpecialties;
                for(let j=0; j<childObj.length; j++) {
                    if(childObj[j]) {
                        childObj[j].selected = false;
                        vm.textFormatService.setRuntimeSpecialtyCount(false);
                    }
                }
            }
        }

        let stateArr = vm.textFormatService.stateList;
        for(let i=0; i<stateArr.length; i++) {
            stateArr[i].selected = false;
        }

        let cityArr = vm.textFormatService.cityList;

        for(let i=0; i<cityArr.length; i++) {
            cityArr[i].selected = false;
        }

        vm.textFormatService.applyFilters();
    }
}

// interface ProgramSummary {
//   programName: string;
//   instName: string;
//   state: string;
//   city: string;
//   region: string;
//   specialty: string;
//   specialtyLink: string;
//   programCd: string;
//   programType: string;
//   erasParticipation: boolean;
//   matchService: string;
// }

const ResidencySearchComponent = {
    template,
    controller: ResidencySearchController,
    controllerAs: 'residencySearch',
    bindings: {
        // context: '<context',
        // roles: '<roles',
        // loggedin: '<loggedin'
    }
};

export default ResidencySearchComponent;
