import { module } from 'angular'; 
import ResidencySearchComponent from './residencySearch.component';

let ResidencySearchModule = module('residencySearch', [])
    .component('residencySearch', ResidencySearchComponent)
    .config(function ($stateProvider, $urlRouterProvider) {
        $stateProvider.state({
            name: 'residencySearch',
            url: "/residency-search",
            template: "<residency-search></residency-search>"
            // resolve: {
            //     loggedin: function (securityService) {
            //         return securityService.isUserLoggedIn();
            //     },
            //     context: function (securityService, loggedin) {
            //         console.log(loggedin);
            //         if (loggedin) {
            //             return securityService.getAuthenticatedUser();
            //         } else {
            //             return false;
            //         }
            //     },
            //     roles: function (context, userRolesService) {
            //         'ngInject';
            //         return userRolesService.getRoles(context);
            //     }
            // }
        });
    });

export default ResidencySearchModule;
