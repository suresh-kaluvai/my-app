import RootModule from './root/root.module';
// yeoman: imports
import * as Highcharts from 'highcharts';

interface Window {
    Highcharts: any;
}

window['Highcharts'] = Highcharts;

import SpecialtyDetailsModule from './specialtyDetails/specialtyDetails.module';
import SpecialtyDetailsResultsModule from './common/services/specialtyDetailsResults/specialtyDetailsResults.module';
import RefDataModule from './common/services/refData/refData.module';
import TextFormatModule from './common/services/textFormat/textFormat.module';
import BackendValidationModule from './common/services/backendValidation/backendValidation.module';
import AlertManagerModule from './common/services/alertManager/alertManager.module';
import SearchResultsModule from './common/services/searchResults/searchResults.module';
import CimTableModule from './common/directives/cimTable/cimTable.module';
import CimInterceptorModule from './common/services/cimInterceptor/cimInterceptor.module';
import UserRolesModule from './common/services/userRoles/userRoles.module';
import MockdataModule from './mockdata/mockdata.module';
import CimFiltersModule from './common/directives/cimFilters/cimFilters.module';
import ResidencySearchModule from './residencySearch/residencySearch.module';
import ProgramDetailsModule from './programDetails/programDetails.module';
import CimSummaryCardModule from './common/directives/cimSummaryCard/cimSummaryCard.module';
import SecondaryNavbarModule from './common/services/secondaryNavbar/secondaryNavbar.module';

export {
    // yeoman: export
    RefDataModule,
    TextFormatModule,
    BackendValidationModule,
    AlertManagerModule,
    SearchResultsModule,
    CimTableModule,
    CimInterceptorModule,
    UserRolesModule,
    MockdataModule,
    CimFiltersModule,
    ResidencySearchModule,
    ProgramDetailsModule,
    CimSummaryCardModule,
    SecondaryNavbarModule,
    RootModule
};