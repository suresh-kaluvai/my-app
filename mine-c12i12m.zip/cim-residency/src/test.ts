// This file is required by karma.conf.js and loads recursively all the .spec and framework files
Error.stackTraceLimit = Infinity;
import 'angular';
import 'angular-mocks/angular-mocks';
import 'core-js/es6';
import 'core-js/es7/reflect';
import 'zone.js/dist/zone';

import 'zone.js/dist/long-stack-trace-zone';
import 'zone.js/dist/sync-test';
import 'zone.js/dist/async-test';
import 'zone.js/dist/fake-async-test';
import 'zone.js/dist/proxy';
import 'zone.js/dist/mocha-patch';

// // Load the mocks
// const mockContext = require.context('../mocks', true, /\.js$/);
// mockContext.keys().forEach(mockContext);

// Then we find all the tests.
const context = require.context('./', true, /(\.|_)spec(\.ts|\.js)$/);
// And load the modules.
context.keys().map(context);

// const componentsContext = require.context('./app/', true, /^(?!.*(\.|_)spec\.ts$).*(\.ts|\.js)$/);
// componentsContext.keys().forEach(componentsContext);