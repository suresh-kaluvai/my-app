import * as angular from 'angular';
import * as $ from 'jquery';
import * as components from './imports';

import uirouter from 'angular-ui-router';
import {NavbarModule, AamcFooterModule, DropdownModule, SideMenuLayoutModule, AamcTableModule  } from 'uiux-components';
import {ApplicationConfigModule, LogModule, ReferenceDataModule} from 'aamc-core';
import { OneAamcModule, SecurityModule, AccountDropdownModule} from 'iam-components';
import 'restangular';
import 'angular-strap';
import 'angular-smart-table';
import 'lodash';
import * as _ from 'lodash';
import 'angularjs-toaster';
import 'ng-tags-input';
import 'angular-sanitize';


var deps = [
  
    uirouter,
    NavbarModule.name,
    AamcFooterModule.name,
    DropdownModule.name,
    SideMenuLayoutModule.name,
    AamcTableModule.name,
    ApplicationConfigModule.name,
    AccountDropdownModule.name,
    SecurityModule.name,
   
  // add third party dependencies here after importing above
  'restangular',
  'mgcrea.ngStrap',
  'smart-table',
  'ngTagsInput',
  'toaster',
  'ngSanitize'
];

for (let key of Object.keys(components)) {
    deps.push(components[key].name);
}

let app = angular.module('cim', deps);

app.config(function($urlRouterProvider, $httpProvider, APP_CONFIG, securityServiceProvider, RestangularProvider, $modalProvider){
    var url = APP_CONFIG.BASE_URL;
    //var url = "https://v-ganatra.adm.aamc.org:8443/"
    $urlRouterProvider.otherwise("/residency-search");
    $httpProvider.defaults.withCredentials = true;
    RestangularProvider.setBaseUrl(url);
    securityServiceProvider.setIncludeRoles(true);
    RestangularProvider.setDefaultHeaders({
        APP_CODE: APP_CONFIG.APP_CODE
    });
    $httpProvider.interceptors.push('cimInterceptorService');

     angular.extend($modalProvider.defaults, {
        html: true
    });
});

angular.element(document).ready(function () {
  $.get('/30/config-service/services-rs/config/CIM', function (appConfig) {
    app.constant('APP_CONFIG', appConfig);
    angular.bootstrap(document, ['cim']);
  });
});
