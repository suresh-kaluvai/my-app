/* SystemJS module definition */
declare var module: NodeModule;
interface NodeModule {
  id: string;
}
declare module '*.html' {
  var _: string;
  export default _;
}
declare module '*.md' {
  var _: string;
  export default _;
}
declare module '*.ts' {
  var _: string;
  export default _;
}