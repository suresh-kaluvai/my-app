export default class SearchResultsServiceProvider { 
    private SearchResults: any;
    constructor(Restangular) {
        'ngInject';
        let $ctrl = this;
        $ctrl.SearchResults = Restangular.one('/cim-rps-service/programSearch');
    }


    getSearchResults(data, params) {
        let $ctrl =this;
        let secondarySort = '';

        switch(params.sort) {
            case 'state,asc':
            case 'state,desc':
                secondarySort = `?sort=${params.sort}&sort=city,asc`;
                params.sort = 'specialtyName,asc';
                break;
            case 'programName,asc':
            case 'programName,desc':
                secondarySort = `?sort=${params.sort}`;
                params.sort = 'specialtyName,asc';
                break;
            case 'specialtyName,asc':
            case 'specialtyName,desc':
                secondarySort = `?sort=${params.sort}&sort=state,asc`;
                params.sort = 'city,asc';
                break;
            default:
                break;
        }

        return $ctrl.SearchResults.customPOST(data, secondarySort, params);
    }

    getKeywordSearchResults(params, programType) {
        let $ctrl =this;
        let secondarySort = '';

        switch(params.sort) {
            case 'state,asc':
            case 'state,desc':
                secondarySort = `?sort=${params.sort}&sort=city,asc`;
                params.sort = 'specialtyName,asc';
                break;
            case 'programName,asc':
            case 'programName,desc':
                secondarySort = `?sort=${params.sort}`;
                params.sort = 'specialtyName,asc';
                break;
            case 'specialtyName,asc':
            case 'specialtyName,desc':
                secondarySort = `?sort=${params.sort}&sort=state,asc`;
                params.sort = 'city,asc';
                break;
            default:
                break;
        }

        return $ctrl.SearchResults.customGET(`${programType}${secondarySort}`, params);
    }
}

// export default class SearchResultsServiceProvider {
//     public $get() {
//         return new SearchResultsService();
//     }
// }
