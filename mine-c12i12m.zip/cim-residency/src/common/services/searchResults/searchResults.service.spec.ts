import * as angular from 'angular';
import 'angular-mocks/angular-mocks';
import { expect } from 'chai';

describe('SearchResultsService', () => {
    let searchResultsService;

    beforeEach(angular.mock.module('backendAuthService'));
    beforeEach(inject(function(_backendAuthService_) {
        searchResultsService = _backendAuthService_;
    }));
});
