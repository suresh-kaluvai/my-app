import {module} from 'angular';
import SearchResultsServiceProvider from './searchResults.service';

let SearchResultsModule = module('searchResults', [])
.service('searchResultsService', SearchResultsServiceProvider);

export default SearchResultsModule;
