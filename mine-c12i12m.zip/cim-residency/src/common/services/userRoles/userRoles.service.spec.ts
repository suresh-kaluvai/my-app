import * as angular from 'angular';
import 'angular-mocks/angular-mocks';
import { expect } from 'chai';

describe('UserRolesService', () => {
    let userRolesService;

    beforeEach(angular.mock.module('backendAuthService'));
    beforeEach(inject(function(_backendAuthService_) {
        userRolesService = _backendAuthService_;
    }));
});
