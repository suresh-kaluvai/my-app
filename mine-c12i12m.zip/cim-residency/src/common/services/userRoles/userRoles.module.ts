import {module} from 'angular';
import UserRolesServiceProvider from './userRoles.service';

let UserRolesModule = module('userRoles', [])
.provider('userRolesService', UserRolesServiceProvider);

export default UserRolesModule;
