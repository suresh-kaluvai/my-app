import * as angular from 'angular';
export class UserRolesService {
    constructor() {
        let vm = this;
    }
    getRoles(context) {
        var role = {
            isMD: false,
            isDO: false,
            isAdmin: false,
            isGuest: true,
            isMultiRoleUser: false,
            isInvalidUser: false
        };
        var userRoles;
        if (context && context.authorities) {
            if (context.authorities.length > 1) {
                role.isMultiRoleUser = true
            } else if (context.authorities.length === 0) {
                role.isInvalidUser = true;
            } else if (context.authorities.length === 1) {
                angular.forEach(context.authorities, function (v) {
                    userRoles = v;
                });
                role.isMD = userRoles.authority.includes("MD ");
                role.isDO = userRoles.authority.includes("DO ");
                role.isAdmin = userRoles.authority === "Admin";
                if (role.isMD || role.isDO || role.isAdmin) {
                    role.isGuest = false;
                }
            }
        }
        return role;
    }
}

export default class UserRolesServiceProvider {
    public $get() {
        return new UserRolesService();
    }
}
