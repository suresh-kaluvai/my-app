import {module} from 'angular';
import AlertManagerServiceProvider from './alertManager.service';

let AlertManagerModule = module('alertManager', [])
.factory('alertManagerService', AlertManagerServiceProvider);

export default AlertManagerModule;
