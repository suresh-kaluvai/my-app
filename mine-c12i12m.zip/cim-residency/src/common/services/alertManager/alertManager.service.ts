// export class AlertManagerService {
//   constructor() {

//   }
// }

// export default class AlertManagerServiceProvider {
//     public $get() {
//         return new AlertManagerService();
//     }
// }

let AlertManagerServiceProvider = function (toaster) {
    'ngInject';

    return {
        backendAlert: function (message, klass) {
            toaster.pop(klass, message);
        },
        infoAlert: function (message, klass) {
            toaster.pop(klass, message);
        }
    };
};

export default AlertManagerServiceProvider;
