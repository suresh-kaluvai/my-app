// export class BackendValidationService {
//   constructor() {

//   }
// }

// export default class BackendValidationServiceProvider {
//     public $get() {
//         return new BackendValidationService();
//     }
// }

let BackendValidationServiceProvider = function ($q, alertsManagerService) {
    'ngInject';

    return {
        responseError: function (response, $http) {
            if (response.status === 403) {
                alertsManagerService.backendAlert("Not Authorized.your error id is:" + response.data.id, 'error');
            }
            else if (response.status === 419 || response.status === 440) {
                alertsManagerService.backendAlert("Session gets Timeout", 'error');
            }
            else if (response.status === 500) {
                alertsManagerService.backendAlert("Error occurred while processing the request. Please try again or contact AAMC for further support. Your error id is:" + response.data.id, 'error');
            }
            else if (response.status === 405) {
                alertsManagerService.backendAlert("Not Allowed. Please try again or contact AAMC for further support.your error id is:" + response.data.id, 'error');
            }
            else if (response.status === 404) {
                alertsManagerService.backendAlert("Service is currently not available. Please try again or contact AAMC for further support.your error id is:" + response.data.id, 'error');
            } else if (response.status === 320) {
                alertsManagerService.backendAlert("Season has closed Please try again next season.your  error id is:" + response.data.id, 'error');
            } else if (response.status !== 401) {
                alertsManagerService.backendAlert("Error occurred while processing the request. Please try again or contact AAMC for further support.your  error id is:" + response.data.id, "error");
            }
            return $q.reject(response);
        }
    };
};

export default BackendValidationServiceProvider;
