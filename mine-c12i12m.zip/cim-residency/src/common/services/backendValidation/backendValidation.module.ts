import {module} from 'angular';
import BackendValidationServiceProvider from './backendValidation.service';

let BackendValidationModule = module('backendValidation', [])
.factory('backendValidationService', BackendValidationServiceProvider);

export default BackendValidationModule;
