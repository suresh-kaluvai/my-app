import * as angular from 'angular';
import 'angular-mocks/angular-mocks';
import { expect } from 'chai';

describe('TextFormatService', () => {
    let textFormatService;

    beforeEach(angular.mock.module('backendAuthService'));
    beforeEach(inject(function(_backendAuthService_) {
        textFormatService = _backendAuthService_;
    }));
});
