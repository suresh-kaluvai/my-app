import {module} from 'angular';
import TextFormatServiceProvider from './textFormat.service';

let TextFormatModule = module('textFormat', [])
.service('textFormatService', TextFormatServiceProvider);

export default TextFormatModule;


