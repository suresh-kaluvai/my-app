// export class TextFormatService {
//     private filterData: any;
//     constructor() {
//         this.filterData = test;
//     }
// }

// export default class TextFormatServiceProvider {
//     public $get() {
//         return new TextFormatService();
//     }
// }

export default class TextFormatServiceProvider {
    private filterData: any;
    private getSearchResult: any;
    private rowCount: any;
    private sortField: any;
    private rowStartIndex: any;
    private resetSortDisplay: any;
    private clearFiltersNotGetResult: any;
    private searchKeyword : any;
    private refSpecialtiesList: any;
    private stateList: any;
    private cityList: any;
    private applyFilters: any;
    private setRuntimeSpecialtyCount: any;

    constructor() {
        'ngInject';
        let $ctrl = this;
        this.filterData = {
            specialtyCds: [],
            programType: null,
            stateCds: [],
            cities: []
        };

        this.rowCount = 10;
        this.sortField = "programName,asc";
        this.rowStartIndex = 0;

        this.getSearchResult = null;
        this.resetSortDisplay = null;
        this.clearFiltersNotGetResult = null;
        this.searchKeyword = '';
        this.refSpecialtiesList = [];
        this.stateList = [];
        this.cityList = [];
        this.applyFilters = '';
        this.setRuntimeSpecialtyCount = '';
    }
}
