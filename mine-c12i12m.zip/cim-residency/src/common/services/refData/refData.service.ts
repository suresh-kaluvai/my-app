export default class RefDataServiceProvider {
  private refData: any;
  constructor(Restangular) {
    'ngInject';
    let $ctrl = this;
    $ctrl.refData = Restangular.one('/cim-rps-service');
  }
  getRefStates() {
    let $ctrl = this;
    return $ctrl.refData.getList('/programSearch/refStates');
  }

  getRefSpecialties(programType) {
    let $ctrl = this; 
    return $ctrl.refData.getList('/programSearch/refSpecialties/' + programType);
  }
   
  getRefCities(data, programType) { 
    let $ctrl = this;
    return $ctrl.refData.post('programSearch/' + programType + '/cities', data);

  }

}
