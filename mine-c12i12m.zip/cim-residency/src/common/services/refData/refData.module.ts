import {module} from 'angular';
import RefDataServiceProvider from './refData.service';

let RefDataModule = module('refData', [])
.service('refDataService', RefDataServiceProvider);

export default RefDataModule;
