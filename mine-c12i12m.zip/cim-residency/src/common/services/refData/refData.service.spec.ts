import * as angular from 'angular';
import 'angular-mocks/angular-mocks';
import { expect } from 'chai';

describe('RefDataService', () => {
    let refDataService;

    beforeEach(angular.mock.module('backendAuthService'));
    beforeEach(inject(function(_backendAuthService_) {
        refDataService = _backendAuthService_;
    }));
});
