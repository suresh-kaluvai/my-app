import * as angular from 'angular';
import 'angular-mocks/angular-mocks';
import { expect } from 'chai';

describe('CimInterceptorService', () => {
    let cimInterceptorService;

    beforeEach(angular.mock.module('backendAuthService'));
    beforeEach(inject(function(_backendAuthService_) {
        cimInterceptorService = _backendAuthService_;
    }));
});
