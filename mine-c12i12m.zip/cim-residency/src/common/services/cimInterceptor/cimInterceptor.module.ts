import {module} from 'angular';
import CimInterceptorServiceProvider from './cimInterceptor.service';

let CimInterceptorModule = module('cimInterceptor', [])
.factory('cimInterceptorService', CimInterceptorServiceProvider);

export default CimInterceptorModule;
