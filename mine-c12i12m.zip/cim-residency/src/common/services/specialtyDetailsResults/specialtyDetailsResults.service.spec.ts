import * as angular from 'angular';
import 'angular-mocks/angular-mocks';
import { expect } from 'chai';

describe('SpecialtyDetailsResultsService', () => {
    let specialtyDetailsResultsService;

    beforeEach(angular.mock.module('backendAuthService'));
    beforeEach(inject(function(_backendAuthService_) {
        specialtyDetailsResultsService = _backendAuthService_;
    }));
});
