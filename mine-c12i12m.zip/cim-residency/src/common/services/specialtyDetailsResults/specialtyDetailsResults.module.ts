import {module} from 'angular';
import SpecialtyDetailsResultsServiceProvider from './specialtyDetailsResults.service';

let SpecialtyDetailsResultsModule = module('specialtyDetailsResults', [])
.service ('specialtyDetailsResultsService', SpecialtyDetailsResultsServiceProvider);

export default SpecialtyDetailsResultsModule;
