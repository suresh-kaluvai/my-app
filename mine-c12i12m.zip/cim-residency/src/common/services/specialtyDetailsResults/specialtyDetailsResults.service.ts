
export default class SpecialtyDetailsResultsServiceProvider {
    private SpecialtyDetailsResults: any;
    constructor(Restangular) {
        'ngInject';
        let $ctrl = this;
        $ctrl.SpecialtyDetailsResults = Restangular.one('/cim-rps-service/specialtyDetailsSearch');
    }
    getSpecialtyDetailsResults(data) {
        let $ctrl = this;
        return $ctrl.SpecialtyDetailsResults.customPOST(data);
    }
}

