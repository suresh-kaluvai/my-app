class SecondaryNavbarService {
    private programName: string;
    constructor() {
        this.programName = null;
    }
}

export default SecondaryNavbarService;
