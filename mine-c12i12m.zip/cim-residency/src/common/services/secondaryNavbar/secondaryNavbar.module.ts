import {module} from 'angular';
import SecondaryNavbarService from './secondaryNavbar.service';

let SecondaryNavbarModule = module('cim.secondary.navbar', [])
.service('secondaryNavbarService', SecondaryNavbarService);

export default SecondaryNavbarModule;
