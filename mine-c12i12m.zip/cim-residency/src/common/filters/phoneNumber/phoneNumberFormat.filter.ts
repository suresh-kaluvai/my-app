// import angular from 'angular';

// class PhoneNumberFormatFilter {

//     static phoneNumber(value) {
//         if (!value) {
//             return '';
//         }


//         value = value.toString().trim().replace(/^\+/, '');

//         if(value.length === 10) {
//             let city = value.slice(0, 3);
//             let number = value.slice(3);

//             number = number.slice(0, 3) + '-' + number.slice(3);

//             return (`( ${city}) + ${number}`).trim();
//         }

//         return value;
//     }
// }

// export default function () {
//     return function (value) {
//         if (!value) {
//             return '';
//         }

//         value = value.toString().trim().replace(/^\+/, '');

//         if(value.length === 10) {
//             let city = value.slice(0, 3);
//             let number = value.slice(3);

//             number = number.slice(0, 3) + '-' + number.slice(3);

//             return (`( ${city}) + ${number}`).trim();
//         }

//         return value;
//     }
// }



