// import angular from 'angular';
// import phoneNumber from './phoneNumberFormat.filter';

// let PhoneNumberFilterModule = angular.module('phoneNumberFilterModule').filter("phonenumber", () => phoneNumber);

// export default PhoneNumberFilterModule;
