export function cimStatus() {
    'ngInject';
    return {
        require: '^cimTable',
        template:
        '<span cim-table-select="applicationStatus" data-title="Application Status"></span>',
        scope: true,
        link: function (scope, el, attr) {
            scope.attr = attr;
        }
    }
};

export default cimStatus;