import { module } from 'angular';
import * as _ from 'lodash';
import CimTableDirective from './cimTable.directive';
import cimTableFilter from './cimTable.directive';
import cimTableHide from './cimTableHide';
import cimTableToolbar from './cimTableToolbar';
import cimTableFooter from './cimTableFooter';
import cimTableRows from './cimTableRows';
import cimTableCount from './cimTableCount';
import cimTableSelect from './cimTableSelect';
import cimStatus from './cimStatus';
import paginationContent from './pagination.html';

let CimTableModule = module('cimTable', [])
    .run(function($templateCache) {
         $templateCache.put('src/common/directives/cimTable/pagination.html', paginationContent);
    })
    .directive('cimTable', CimTableDirective)
    .filter("cimTableFilter", cimTableFilter)
    .directive("cimTableHide", cimTableHide)
    .directive("cimTableToolbar", cimTableToolbar)
    .directive("cimTableFooter", cimTableFooter)
    .directive("cimTableRows", cimTableRows)
    .directive("cimTableCount", cimTableCount)
    .directive("cimTableSelect", cimTableSelect)
    .directive("cimStatus", cimStatus);

export default CimTableModule;
