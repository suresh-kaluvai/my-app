import * as _ from 'lodash';
export function cimTableSelect() {
    return {
        require: '^cimTable',
        scope: {
            cimTableSelect: '@',
            options: '=?',
            value: '=?',
            title: '@?'
        },

        template: '<span ng-if="options.length>1"><label>{{title}}: </label> <select class="c-select" ng-model="$parent.value" ' +
        'ng-options="a.value as a.label for a in options"></select></span>',

        link: function (scope, el, attr, cimTable) {
            // Make sure there's a st-safe-src attribute
            if (!cimTable.safeSource) {
                throw "Table filters require a safe source.";
            }

            if (!attr.options) {
                scope.$watchCollection(function () {
                    return cimTable.rawData;
                }, function (data) {
                    var values = _.uniq(_.map(data, attr.cimTableSelect));

                    values.sort();

                    scope.options = _.map(values, function (a) {
                        return { label: a, value: a };
                    });

                    if (scope.options.length > 1) {
                        scope.options.unshift({ label: 'All' });
                    }
                });
            }

            function update(val) {
                cimTable.stTable.search(val, attr.cimTableSelect);
            }

            scope.$watch('value', update);
        }
    }
};


export default cimTableSelect;