import * as _ from 'lodash';
export function CimTableDirective() {
  return {
        require: 'stTable',
        scope: false,

        compile: function (el, attr) {
            var cls = 'table ' + ('cimTableList' in attr ? '' : 'table-hover');

            el.find('table').wrap('<div class="table-responsive">')
                .addClass(cls).prepend()
                ;

        },

        controllerAs: 'cimTable',

        controller: function ($scope, $element, $attrs) {
            var vm = this, columns;
            vm.safeSource = !!$attrs.stSafeSrc;
            vm.dataSource = $attrs.stSafeSrc ? $attrs.stSafeSrc : $attrs.stTable;
            vm.dataGetter = $attrs.stTable;
            vm.stTable = $element.data('$stTableController');
            vm.table = $element.find('table');
            vm.selected = [];
            vm.available = [];

            // Override filter function
            //if (vm.stTable) {
            //    vm.state = vm.stTable.tableState();
            //    vm.stTable.setFilterFunction('cimTableFilter');
            //}

            //if (!vm.safeSource)
            //    window.console.warn("No st-safe-src attribute present");

            // Emit event on table update
            $scope.$watch(vm.dataGetter, update);
            $scope.$watch(function () {
                columns = vm.table.find('th');
                return columns.length;
            }, updateColumns);

            function updateColumns() {
                // Clear watches
                if (vm.columns) {
                    _.invoke(vm.columns, 'watch');
                }


                vm.columns = columns.map(function (i) {
                    var el = $(this);
                    var col = {
                        th: el,
                        index: i + 1,
                        text: el.text(),
                        field: el.attr('cim-table-field') || el.attr('st-sort'),
                        visible: true,
                        ignore: this.hasAttribute('cim-ignore') || this.hasAttribute('cim-table-actions'),
                        watch : false
                    };

                    col.watch = $scope.$watch(function () {
                        return col.visible;
                    },
                        function (val) {
                            col.th.toggle(val);
                            vm.table.find('tbody > tr[ng-repeat] > td:nth-child(' + col.index +
                                '), tbody[ng-repeat] > tr:eq(0) > td:nth-child(' + col.index + ')')
                                .toggle(val);
                        });

                    return col;

                });

            }

            function update(val) {
                vm.data = val;
                vm.rawData = $scope.$eval(vm.dataSource);
                $scope.$emit('cimTable:update', val);
            }
        }

    }
}

export default CimTableDirective;