export function cimTableCount() {
    return {

        require: '^cimTable',
        template: 'Showing {{start}} - ' +
        '{{pag.start + (pag.number > total-pag.start ? total-pag.start : pag.number)}}' +
        ' of {{total}}',

        link: function (scope, el, attr, table) {
            //scope.state = table.state;
            //scope.pag = table.state.pagination;
            //
            //scope.$watchCollection('cimTable.state.pagination', function(val) {
            //    scope.total = val.totalItemCount;
            //    scope.start = scope.total ? scope.pag.start+1 : 0;
            //});
            scope.state = scope.cimTable.stTable.tableState();
            scope.pag = scope.state.pagination;

            scope.$watchCollection('state.pagination', function (val) {
                scope.total = val.totalItemCount;
                scope.start = scope.total ? scope.pag.start + 1 : 0;
            });
        }

    }
};


export default cimTableCount;