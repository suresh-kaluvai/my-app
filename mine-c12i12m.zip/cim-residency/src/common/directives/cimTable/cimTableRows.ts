export function cimTableRows() {
    'ngInject';
    return {
        require: '^cimTable',
        scope: {
            selected: '=?'
        },
        template: '<label>Display:</label> <select class="c-select" ' +
        'ng-model="selected" ng-options="option.value as option.label for ' +
        'option in options" ng-change="change()" id="itemsPerPageSelect"></select>',
        link: function (scope, el, attr, cimTable) {
            scope.options = [
                { value: 10, label: '10' },
                { value: 25, label: '25' },
                { value: 50, label: '50' }
            ];

            scope.$watch(
                function(scope) { return scope.selected }, 
                function(newVal, oldVal) { 
                    scope.change();
                }
            );
            //scope.$on('$select.select', function() {
            scope.change = function () {
                //scope.$apply(cimTable.stTable.slice.bind(cimTable.stTable, 0, scope.selected));
                //console.log(cimTable.stTable.tableState().pagination.totalItemCount);
                cimTable.state.pagination.number = parseInt(scope.selected);
                cimTable.stTable.slice(0, scope.selected);
            };

            //});
        }
    }
};

export default cimTableRows;