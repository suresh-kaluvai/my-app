export function cimTableHide() {
    'ngInject';
    return {
        restrict: 'A',
        require: '^cimTable',
        scope: {
            cimTableHide: '='
        },

        link: function (scope, el, attr, cimTable) {
            scope.$watch('cimTableHide', function (val) {
                var i = el.data('index');
                var col = cimTable.columns[i];

                if (col) {
                    col.visible = !val;
                }
            });
        }

    }
};

export default cimTableHide;