import template from './cim-table-footer.html';
export function cimTableFooter() {
    'ngInject';
    return {
        restrict: 'A',
        template: template
    }
};

export default cimTableFooter;