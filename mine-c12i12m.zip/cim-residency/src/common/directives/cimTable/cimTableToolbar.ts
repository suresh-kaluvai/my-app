import template from './cim-table-toolbar.html';
export function cimTableToolbar() {
    'ngInject';
    return {
        restrict: 'A',
        template: template
    }
};


export default cimTableToolbar;