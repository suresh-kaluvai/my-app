import { module } from 'angular';
import '@iamadamjowett/angular-click-outside';
import CimFiltersDirective from './cimFilters.directive'; 

let CimFiltersModule = module('cimFilters', ['angular-click-outside'])
    .directive('cimFilters', CimFiltersDirective);

export default CimFiltersModule;
