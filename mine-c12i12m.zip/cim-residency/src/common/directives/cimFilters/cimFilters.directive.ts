import template from './cimFilters.directive.html';
import CimFiltersController from './cimFilters.directive.controller';
export function CimFiltersDirective() {
  return {
    restrict: "E",
    replace: true,
    scope: {
      roles:'='
    },
    template: template,
    transclude: true,
    controller: CimFiltersController,
    controllerAs: 'cimFilters',
    bindToController: true
  };
}
  
export default CimFiltersDirective;