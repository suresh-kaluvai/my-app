
import * as angular from "angular";

class CimFiltersController {
    private filterData: any;
    private showSpecialtyMenu: any;
    private showStateMenu: any;
    private showCityMenu: any;
    private textFormatService: any;
    private defaultProgramType: any;
    private defaultState: any;
    private cities: any;
    private refSpecialties: any;
    private states: any;
    private runtimeSelSpecialties: number;

    constructor(private $scope, textFormatService, private refDataService) {
        let vm = this;
        vm.$scope = $scope;
        vm.refDataService = refDataService;
        vm.textFormatService = textFormatService;

        vm.showSpecialtyMenu = false;
        vm.showStateMenu = false;
        vm.showCityMenu = false;
        vm.textFormatService.clearFiltersNotGetResult = vm.clearFiltersNotGetResult.bind(vm);
        vm.textFormatService.applyFilters = vm.applyFilters.bind(vm);
        vm.textFormatService.setRuntimeSpecialtyCount = vm.setRuntimeSpecialtyCount.bind(vm);
    }

    $onInit() {
        let vm = this;
        vm.filterData = vm.textFormatService.filterData;
        vm.runtimeSelSpecialties = vm.filterData.specialtyCds.length;
        if(!vm.filterData.programType) {
            vm.$scope.$watch('cimFilters.roles', function (val) {
                if (val.isDO) {
                    vm.filterData.programType = 'OSTEOPATHIC';
                } else {
                    vm.filterData.programType = 'ACGME';
                }

                vm.getRefSpecialites();
            });
        }

        vm.getRefSpecialites();
    }
    
    getRefSpecialites() {
        let vm = this;
        if(!vm.filterData.programType) {
            return;
        }

        vm.refSpecialties = [];
        vm.refDataService.getRefSpecialties(vm.filterData.programType).then(function (res) {
            let specialtiesData = res.plain();
            vm.refSpecialties = vm.setSpecialtyFilters(specialtiesData);
            vm.textFormatService.refSpecialtiesList = vm.refSpecialties;
            vm.getStatesList();
        });
    }

    getStatesList() {
        let vm = this;
        vm.refDataService.getRefStates().then(function (res) {
            let stateList = res.plain();
            vm.states = vm.setStateFilters(stateList);
            vm.textFormatService.stateList = stateList;
            
            if(vm.filterData.stateCds && vm.filterData.stateCds.length > 0) {
                vm.getCities(true);
            } else {
                vm.applyFilters();
            }

        });
    }

    applyFilters() {
        let vm = this;
        vm.textFormatService.searchKeyword = '';
        vm.filterData.specialtyCds = vm.getSelectedSpecialites();
        vm.filterData.stateCds = vm.getSelectedStates();
        vm.filterData.cities = vm.getSeletectedCitites();
        vm.textFormatService.filterData = vm.filterData;
        vm.textFormatService.getSearchResult();
    }

    getSelectedSpecialites() {
        let vm = this;
        var selectedSpecialties = [];

        vm.refSpecialties.map(specialty => {
            if(specialty.parentSpecialty && specialty.parentSpecialty.selected) {
                selectedSpecialties.push(specialty.parentSpecialty.specialtyCd);
            }

            if(specialty.childSpecialties && specialty.childSpecialties.length > 0 ) {
                specialty.childSpecialties.map((childSpecialtyObj) => {
                    if(childSpecialtyObj.selected) {
                        selectedSpecialties.push(childSpecialtyObj.specialtyCd);
                    }
                });
            }
        }); 

        return selectedSpecialties;
    }

    getSelectedStates() {
        let vm = this;
        let selectedStates = [];

        vm.states.map(state => {
            if(state.selected) {
                selectedStates.push(state.stateCd);
            }
        });

        return selectedStates;
    }

    getSeletectedCitites() {
        let vm = this;
        let selectedCitiesWithStates = {};
        let cities = [];

        vm.cities && vm.cities.map(cityObj => {
            if(cityObj.selected) {
                if(selectedCitiesWithStates[cityObj.stateCd]) {
                    selectedCitiesWithStates[cityObj.stateCd].push(cityObj.city);
                } else {
                    selectedCitiesWithStates[cityObj.stateCd] = [cityObj.city];
                }
            }
        });

        for (var stateCode in selectedCitiesWithStates) {
            if (selectedCitiesWithStates.hasOwnProperty(stateCode)) {
                cities.push({ 'stateCd': stateCode, 'cities': selectedCitiesWithStates[stateCode] });
            }
        }
        
        return cities;
    }

    getCities(setFilter) {
        let vm = this;

        vm.filterData.stateCds = vm.getSelectedStates();
        return vm.refDataService.getRefCities(vm.filterData.stateCds, vm.filterData.programType).then(function (res) {
            vm.cities = res.plain();
            vm.textFormatService.cityList = vm.cities;
            if(setFilter) {
                if(vm.filterData.cities && vm.filterData.cities.length > 0) {
                    vm.setCityFilters(vm.filterData.cities);
                }
            }
        });
    }

    changeProgramType() {
        let vm = this;
        vm.getRefSpecialites();
        vm.textFormatService.searchKeyword = '';
        vm.clearFilters();
    }

    clearFilters() {
        let vm = this;

        vm.textFormatService.searchKeyword = '';
        vm.filterData.stateCds = [];
        vm.filterData.cities = [];
        vm.filterData.specialtyCds = [];
        vm.textFormatService.filterData = vm.filterData;
        vm.textFormatService.resetSortDisplay();

        vm.refSpecialties = vm.resetRefSpecialties(vm.refSpecialties);
        vm.states = vm.resetFilters(vm.states);
        vm.cities = [];
        vm.runtimeSelSpecialties = 0;

        vm.textFormatService.getSearchResult();
    }

    resetFilters(resetData) {
        return resetData.map(dataObj => { 
            dataObj.selected = false; 
            return dataObj;
        });
    }

    resetRefSpecialties(resetData) {
        return resetData.map((specialty) => {
            if(specialty.parentSpecialty) {
                specialty.parentSpecialty.selected = false;
            }

            if(specialty.childSpecialties) {
                specialty.childSpecialties.map((childSpecialty) => {
                    childSpecialty.selected = false;
                });
            }
             
            return specialty;
        });
    }

    clearFiltersNotGetResult() {
        let vm = this;
        vm.filterData.stateCds = [];
        vm.filterData.cities = [];
        vm.filterData.specialtyCds = [];
        vm.textFormatService.filterData = vm.filterData;
        vm.textFormatService.resetSortDisplay();
        vm.runtimeSelSpecialties = 0;

        vm.refSpecialties = vm.resetRefSpecialties(vm.refSpecialties);
        vm.states = vm.resetFilters(vm.states);
        vm.cities = [];
    }

    setStateFilters(stateList) {
        let vm = this;
        let stateObjArr = [];
        stateObjArr =  stateList.map((state) => {
            (vm.filterData.stateCds.length > 0 &&  vm.filterData.stateCds.includes(state.stateCd)) ? state.selected = true : state.selected = false; 
            return state;
        });
        
        return stateObjArr;
    }

    setCityFilters(cityFilterList) {
        let vm = this;
        let cityObjArr = cityFilterList.map((cityFilter) => {
             vm.cities.map((cityObj) => {
                 if((cityObj.stateCd === cityFilter.stateCd) && cityFilter.cities.includes(cityObj.city) ) {
                    cityObj.selected = true;
                 } else {
                    cityObj.selected = false;
                 }

                 return cityObj;
             });   
        });
    }

    setSpecialtyFilters(specialtyList) {
        let vm = this;
        let specialtyObjArr = [];

        specialtyObjArr =  specialtyList.map((specialty) => {
            if(specialty.parentSpecialty) {
                (vm.filterData.specialtyCds.length > 0 && vm.filterData.specialtyCds.includes(specialty.parentSpecialty.specialtyCd)) ? specialty.parentSpecialty.selected = true : specialty.parentSpecialty.selected = false;
            }

            if(specialty.childSpecialties) {
                specialty.childSpecialties.map((childSpecialty) => {
                    (vm.filterData.specialtyCds.length > 0 && vm.filterData.specialtyCds.includes(childSpecialty.specialtyCd)) ? childSpecialty.selected = true : childSpecialty.selected = false;
                }
                );
            }
             
            return specialty;
        });

        return specialtyObjArr;
    }

    closeSelectDropdown(hideSection) {
        let vm = this;
        vm[hideSection] = false;
    }

    setRuntimeSpecialtyCount(isSelected) {
        let vm = this;
        if(vm.runtimeSelSpecialties >= 0) {
            isSelected ? vm.runtimeSelSpecialties++ : vm.runtimeSelSpecialties--;

            if(vm.runtimeSelSpecialties < 0) {
                vm.runtimeSelSpecialties = 0
            }
        }
    }
}

export default CimFiltersController;
