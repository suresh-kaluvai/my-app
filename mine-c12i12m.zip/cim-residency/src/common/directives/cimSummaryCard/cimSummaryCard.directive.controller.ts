class CimSummaryCardController {

    constructor(private $modal, private securityService, private APP_CONFIG, private $window) {
        let vm = this;
        vm.$modal = $modal;
        vm.securityService = securityService;
        vm.APP_CONFIG = APP_CONFIG;
        vm.$window = $window;
    }

    $onInit() {
        let vm = this;
    }

    goToSubscribe() {
        let vm = this;
        vm.$window.location.href = vm.APP_CONFIG.SUBSCRIPTION_URL;
    }
}

export default CimSummaryCardController;
