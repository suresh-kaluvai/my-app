import template from './cimSummaryCard.directive.html';
import CimSummaryCardController from './cimSummaryCard.directive.controller';
export function CimSummaryCardDirective() {
  return {
    restrict: "E",
    replace: true,
    scope: {
      schoolData: '=',
      roles:'='
    },
    template: template,
    transclude: true,
    controller: CimSummaryCardController,
    controllerAs: 'cimSummaryCard',
    bindToController: true
  };
}

export default CimSummaryCardDirective;