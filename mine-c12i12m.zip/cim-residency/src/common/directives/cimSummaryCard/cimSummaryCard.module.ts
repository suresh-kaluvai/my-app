import { module } from 'angular';
import CimSummaryCardDirective from './cimSummaryCard.directive';
import CimSummaryCardController from './cimSummaryCard.directive.controller';
import signinTemplate from './modal/signin.modal.html';
import subscribeTemplate from './modal/subscribe.modal.html';

let CimSummaryCardModule = module('cimSummaryCard', [])
    .run(function($templateCache) {
        $templateCache.put('modal/signin.modal.html', signinTemplate);
        $templateCache.put('modal/subscribe.modal.html', subscribeTemplate);
    })
    .directive('cimSummaryCard', CimSummaryCardDirective)
    .controller('cimSummaryCard', CimSummaryCardController);

export default CimSummaryCardModule;
