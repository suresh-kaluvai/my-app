import * as angular from 'angular';
import 'angular-mocks/angular-mocks';
import { expect } from 'chai';

describe('MockdataService', () => {
    let mockdataService;

    beforeEach(angular.mock.module('backendAuthService'));
    beforeEach(inject(function(_backendAuthService_) {
        mockdataService = _backendAuthService_;
    }));
});
