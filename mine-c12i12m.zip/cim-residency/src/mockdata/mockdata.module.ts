import {module} from 'angular';
import MockdataServiceProvider from './mockdata.service';

let MockdataModule = module('mockdata', [])
.provider('mockdataService', MockdataServiceProvider);

export default MockdataModule;
