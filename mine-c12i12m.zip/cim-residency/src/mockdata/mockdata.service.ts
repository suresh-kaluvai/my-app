import { demoData } from '../mockdata/demo-data';
export class MockdataService {
    constructor() {

    }
    getMockData() {
        return demoData;
    }
}

export default class MockdataServiceProvider {
    public $get() {
        return new MockdataService();
    }
}
