import {module} from 'angular';
import overview from './overview.html';
import programContact from './programContact.html';
import programDescription from './programDescription.html';
import acceptanceAndProgress from './acceptanceAndProgress.html';
import programSetting from './programSetting.html';
import graduateCareerPlans from './graduateCareerPlans.html';
import residentCharacteristics from './residentCharacteristics.html';
import residentDemographics from './residentDemographics.html';

let ProgDetailsTemplateModule = module('programDetailsTemplate', [
])
.run(function($templateCache) {
    $templateCache.put('template/overview.html', overview);
    $templateCache.put('template/programContact.html', programContact);
    $templateCache.put('template/programDescription.html', programDescription);
    $templateCache.put('template/acceptanceAndProgress.html', acceptanceAndProgress);
    $templateCache.put('template/programSetting.html', programSetting);
    $templateCache.put('template/graduateCareerPlans.html', graduateCareerPlans);
    $templateCache.put('template/residentCharacteristics.html', residentCharacteristics);
    $templateCache.put('template/residentDemographics.html', residentDemographics);
});

export default ProgDetailsTemplateModule;
