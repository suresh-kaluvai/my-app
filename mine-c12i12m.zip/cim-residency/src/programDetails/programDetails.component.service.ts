import {module} from 'angular';

class ProgramDetailsService {
    private restangular: any;
     'ngInject';
    constructor(private Restangular, private $q) {
        let vm = this;
        vm.restangular = Restangular;
        vm.$q = $q;
    }

    getProgramDetail(programCode) {
        let vm = this;
        return vm.restangular.one(`/cim-rps-service/programDetails`, programCode).get();
    }
}

export default ProgramDetailsService;
