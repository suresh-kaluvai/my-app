import {module} from 'angular';
import 'angular-scroll';
import 'highcharts-ng';
import templateModule from './template/template.module';
import ProgramDetailsComponent from './programDetails.component';
import ProgramDetailsService from './programDetails.component.service';

let ProgramDetailsModule = module('programDetails', [
    templateModule.name,
    'duScroll',
    'highcharts-ng'

])
.component('programDetails', ProgramDetailsComponent)
.service('programDetailsService', ProgramDetailsService)
.config(function ($stateProvider, $urlRouterProvider) {
    $stateProvider.state({
        name: 'programDetailsState',
        url: "/program-details/:programCode",
        template: `<program-details program-data='$resolve.programData'></program-details>`,
        resolve: {
            /* @ngInject */
            programData: function($stateParams, $q, programDetailsService) {
                let programCode: Object = $stateParams.programCode;
                return programDetailsService.getProgramDetail(programCode);
            }
        }
    });
});

export default ProgramDetailsModule;
