import * as angular from "angular";
import * as Highcharts from 'highcharts';
import * as Treemap from 'highcharts-treemap';
import * as Highchartsmore from 'highcharts-more';
import template from './programDetails.component.html';
import * as maps from 'google-maps';

class ProgramDetailsController {
    private testObj: any;
    private programData: any;
    private applicationsChartConfig: any;
    private currentResidentsChartConfig: any;
    private areaTypeChartConfig: any;
    private residentMapConfig: any;
    private countries: any;
    private defaultSeriesData: any;
    private Highcharts: any;
    private statesMapConfig: any;
    private ageChartConfig: any;
    private sexChartConfig: any;
    private raceEthnicityChartConfig: any;
    private priorExpResConfig: any;
    private medSchoolNames: any;
    private careerGradPlansData: any;
    private timeSpentTrainingChartConfig: any;
    private chartWidthObject: any;
    private usmdHonorExpChart: any;
    private otherHonorExpChart: any;
    private medicalSchoolDisplayConfig: any;
    private GoogleMapsLoader: any;

    constructor(private secondaryNavbarService, private $timeout) {
        let vm = this;
        vm.secondaryNavbarService = secondaryNavbarService;
        vm.Highcharts = Highcharts;
        vm.$timeout = $timeout;
        Treemap(vm.Highcharts);
        Highchartsmore(vm.Highcharts);
        vm.GoogleMapsLoader = maps;
        vm.GoogleMapsLoader.KEY = 'AIzaSyCP4wISW0yf_4P3pKCCPjoVcSIPfQXJ0UE';
    }

    $onInit() {
        let vm = this;
        vm.programData = vm.programData.plain();
        vm.programData.totalNumberOfResidents = vm.programData.acceptanceAndProgress.currentResidents ? vm.programData.acceptanceAndProgress.currentResidents.totalResCount : null;
        vm.chartWidthObject = {};
        vm.secondaryNavbarService.programName = vm.programData.overview.programName;
        vm.medicalSchoolDisplayConfig = {
            isInternationalSchoolDisabled: false,
            isAmericanSchoolDisabled: false
        };
        
      

        vm.Highcharts.setOptions({
            colors: ['#035BAC', '#3E9EC5', '#E86560', '#E78238', '#FBD44A', '#6CC24A', '#CD453B']
        });

        vm.$timeout(() => {
            let containerDivEle = document.getElementById('overContainerDiv');
            let containerDivWidth = containerDivEle.clientWidth;
            vm.chartWidthObject.smallChartWidth = Math.floor((containerDivWidth/2) - 80);
            vm.chartWidthObject.smallChartLegendWidth =  Math.floor(vm.chartWidthObject.smallChartWidth * 0.3)
            vm.chartWidthObject.fullChartWidth =  Math.floor(containerDivWidth - 80);
            vm.chartWidthObject.fullChartLegendWidth =  Math.floor(vm.chartWidthObject.fullChartWidth * 0.2);

            vm.programData.acceptanceAndProgress && vm.programData.acceptanceAndProgress.applications &&
            vm.prepareNumberOfApplicantsChart(vm.programData.acceptanceAndProgress.applications);
            vm.programData.acceptanceAndProgress && vm.programData.acceptanceAndProgress.currentResidents &&
                vm.prepareCurrentResidentsChart(vm.programData.acceptanceAndProgress.currentResidents);
            vm.programData.programSetting && vm.programData.programSetting.percentAreaType &&
                vm.prepareTrainingLocationChart(vm.programData.programSetting.percentAreaType);
            vm.programData.programSetting && vm.programData.programSetting.percentTimeSpentEachSetting &&
                vm.prepareTimeSpentTrainingChart(vm.programData.programSetting.percentTimeSpentEachSetting);
            vm.programData.demographics && vm.programData.demographics.age &&
                vm.prepareAgeChart(vm.programData.demographics.age);
            vm.programData.demographics && vm.programData.demographics.gender &&
                vm.prepareSexChart(vm.programData.demographics.gender);
            vm.programData.demographics && vm.programData.demographics.raceEthnicity &&
                vm.prepareRaceEthnicityChart(vm.programData.demographics.raceEthnicity);
            vm.programData.characteristics && vm.programData.characteristics.prioExp &&
                vm.preparePriorExpChart(vm.programData.characteristics.prioExp);
            vm.medSchoolNames = [];
            vm.programData.characteristics && vm.programData.characteristics.resMedSchools &&
                vm.prepareResidentsTable(vm.programData.characteristics.resMedSchools);
            vm.programData.demographics && vm.programData.demographics.raceEthnicity &&
                vm.prepareRaceEthnicityChart(vm.programData.demographics.raceEthnicity);

            vm.programData.gradCareerPlans && vm.prepareCareerPlans(vm.programData.gradCareerPlans);

            vm.programData.contact && vm.loadMap(vm.programData.contact);
        });
    }

    prepareNumberOfApplicantsChart(applicationsData) {
        let vm = this;
        let categories = [];
        let categoriesData = [];

        applicationsData.map(data => {
            categories.push(data.gmeYr);
            categoriesData.push(data.totalAppCnt);
        });

        vm.applicationsChartConfig = {
            chart: {
                type: 'line',
                width: vm.chartWidthObject.smallChartWidth
            },
            title: {
                text: ''
            },
            credits: {
                enabled: false
            },
            xAxis: {
                categories: categories
            },
            tooltip: {
                formatter: function () {
                    return '<b>' + this.x + ':</b> ' + this.y;
                }
            },
            plotOptions: {
                series: {
                    marker: {
                        fillOpacity: 1
                    },
                    events: {
                        legendItemClick: function () {
                            return false;
                        }
                    }
                }
            },
            series: [{
                showInLegend: false,
                name: 'Years',
                data: categoriesData
            }],
            responsive: {
                rules: [{
                    condition: {
                        maxWidth: 400
                    },
                    chartOptions: {
                        chart: {
                          className: 'small-chart'
                        },
                        legend: {
                            align: 'center',
                            verticalAlign: 'bottom',
                            layout: 'horizontal'
                        },
                        yAxis: {
                            labels: {
                                align: 'left',
                                x: 0,
                                y: -5
                            },
                            title: {
                                text: null
                            }
                        },
                        subtitle: {
                            text: null
                        },
                        credits: {
                            enabled: false
                        }
                    }
                }]}
        };
    }

    prepareCurrentResidentsChart(currentResidentsData) {
        let vm = this;
        let valueArr = [];

        for (let key in currentResidentsData) {
            if ( key !== 'totalResCount' && currentResidentsData.hasOwnProperty(key)) {
                valueArr.push(currentResidentsData[key]);
            }
        }

        let valLength = valueArr.length;

        for(var i=valLength-1; i >= 0; i--) {
            if(valueArr[i] === null) {
                    valueArr.pop();
            } else {
                break;
            }
        }

        let dataSet = [];

        if(valueArr.length > 0) {
            valueArr.forEach((value, i) => {
                dataSet.push([`Year ${i + 1}`, value ? value : 0]);
            });
        }

        if(dataSet.length > 0) {
            vm.currentResidentsChartConfig = {
                chart: {
                    type: 'column',
                    width: vm.chartWidthObject.smallChartWidth
                },
                title: { text: '' },
                credits: {
                    enabled: false
                },
                xAxis: { type: 'category' },
                yAxis: {
                    min: 0,
                    title: { text: 'Number of Residents' }
                },
                tooltip: {
                    formatter: function () {
                        return '<b>' + this.key + ':</b> ' + this.y;
                    }
                },
                plotOptions: {
                    series: {
                        marker: {
                            fillOpacity: 1
                        },
                        events: {
                            legendItemClick: function () {
                                return false;
                            }
                        }
                    }
                },
                series: [{
                    showInLegend: false,
                    name: 'Number of Residents',
                    data: dataSet
                }]
            };
        }
    }

    prepareTrainingLocationChart(percentAreaType) {
        let vm = this;
        
        if(Object.keys(percentAreaType).length === 0) {
            return;
        }

        vm.areaTypeChartConfig = {
            chart: {
                type: 'pie',
                width: vm.chartWidthObject.smallChartWidth
            },
            legend: {
                align: 'right',
                verticalAlign: 'middle',
                layout: 'vertical',
                width: vm.chartWidthObject.smallChartLegendWidth,
                itemStyle: {
                    textOverflow: null
                }
            },
            title: { text: '' },
            credits: {
                enabled: false
            },
            tooltip: {
                formatter: function () {
                    return '<b>' + this.point.name + ':</b> ' + this.y + '%';
                }
            },
            plotOptions: {
                pie: {
                    allowPointSelect: false,
                    cursor: 'pointer',
                    dataLabels: {
                        enabled: true,
                        format: '<b>{point.y} %</b>',
                        distance: -50,
                    },
                    showInLegend: true,
                    point: {
                        events: {
                            legendItemClick: function () {
                                return false;
                            }
                        }
                    }
                },
                marker: {
                    fillOpacity: 1
                }
            },
            series: [{
                colorByPoint: true,
                data: []
            }]
        };

        for (let property in percentAreaType) {
           vm.areaTypeChartConfig.series[0].data.push({
               name: vm.getTypeOfAreaTooltipName(property),
               y: parseFloat(percentAreaType[property])
           });
        }
    }

    getTypeOfAreaTooltipName(dbName) {
        switch(dbName) {
            case 'A rural area':
                dbName = 'Rural';
                break;
            case 'A suburban area':
                dbName = 'Suburban';
                break;
            case 'An urban area':
                dbName = 'Urban';
                break;
            default:
                break;
        }

        return dbName;
    }

    prepareTimeSpentTrainingChart(percentTimeSpent) {
        let vm = this;

        if(Object.keys(percentTimeSpent).length === 0) {
            return;
        }

        vm.timeSpentTrainingChartConfig = {
            chart: {
                type: 'pie',
                width: vm.chartWidthObject.smallChartWidth
            },
            legend: {
                align: 'right',
                verticalAlign: 'middle',
                layout: 'vertical',
                width: vm.chartWidthObject.smallChartLegendWidth,
                itemStyle: {
                    textOverflow: null
                }
            },
            title: { text: '' },
            credits: {
                enabled: false
            },
            tooltip: {
                formatter: function () {
                    return '<b>' + this.point.name + ':</b> ' + this.y + '%';
                }
            },
            plotOptions: {
                pie: {
                    allowPointSelect: false,
                    cursor: 'pointer',
                    dataLabels: {
                        enabled: true,
                        format: '<b>{point.y} %</b>',
                        distance: -50,
                    },
                    showInLegend: true,
                    point: {
                        events: {
                            legendItemClick: function () {
                                return false;
                            }
                        }
                    }
                },
                marker: {
                    fillOpacity: 1
                }
            },
            series: [{
                colorByPoint: true,
                data: []
            }]
        };

        for (let property in percentTimeSpent) {
           vm.timeSpentTrainingChartConfig.series[0].data.push({
               name: (property === 'Ambulatory (non-hospital) setting') ? 'Ambulatory setting' : property,
               y: parseFloat(percentTimeSpent[property])
           });
        }
    }

    prepareAgeChart(ageData) {
        let vm = this;

        let ageTotalPercentage = 0;
        for (const key of Object.keys(ageData)) {
            ageData[key];
            if(ageData[key]) {
                ageTotalPercentage +=  ageData[key];
            }
        }

         vm.ageChartConfig = {
            chart: {
                type: 'pie',
                width: vm.chartWidthObject.smallChartWidth
            },
            legend: {
                align: 'right',
                verticalAlign: 'middle',
                layout: 'vertical',
                width: vm.chartWidthObject.smallChartLegendWidth,
                itemStyle: {
                    textOverflow: null
                }
            },
            title: { text: '' },
            credits: {
                enabled: false
            },
            tooltip: {
                formatter: function () {
                    return '<b>' + this.point.tooltipName + ':</b> ' + this.y + '%';
                }
            },
            plotOptions: {
                pie: {
                    allowPointSelect: false,
                    cursor: 'pointer',
                    dataLabels: {
                        enabled: true,
                        format: '<b>{point.y} %</b>',
                        distance: -50,
                    },
                    showInLegend: true,
                    point: {
                        events: {
                            legendItemClick: function () {
                                return false;
                            }
                        }
                    }
                },
                marker: {
                    fillOpacity: 1
                }
            },
            series: [{
                name: 'Age Percentage',
                colorByPoint: true,
                data: [
                    {
                        name: '<25 years old',
                        tooltipName: '<25 yo',
                        y: ageData.percentUnder25
                    }, {
                        name: '25-30 years old',
                        tooltipName: '25-30 yo',
                        y: ageData.percent25To30
                    }, {
                        name: '31-35 years old',
                        tooltipName: '31-35 yo',
                        y: ageData.percent31To35
                    }, {
                        name: '36-40 years old',
                        tooltipName: '36-40 yo',
                        y: ageData.percent36To40
                    }, {
                        name: '41-45 years old',
                        tooltipName: '41-45 yo',
                        y: ageData.percent41To45
                    }, {
                        name: '>45 years old',
                        tooltipName: '>45 yo',
                        y: ageData.percentAbove45
                    }
                ]
            }]
         };


        ageTotalPercentage < 100 && vm.ageChartConfig.series[0].data.push({
            name: 'unknown',
            tooltipName: 'unknown',
            y: 100 - ageTotalPercentage
        });
    }

    prepareSexChart(sexData) {
        let vm = this;

        let sexTotalPercentage = 0;
        for (const key of Object.keys(sexData)) {
            if(sexData[key] && key !== 'percentOther') {
                sexTotalPercentage +=  sexData[key];
            }
        }

        vm.sexChartConfig = {
            chart: {
                type: 'pie',
                width: vm.chartWidthObject.smallChartWidth
            },
            legend: {
                align: 'right',
                verticalAlign: 'middle',
                layout: 'vertical',
                width: vm.chartWidthObject.smallChartLegendWidth,
                itemStyle: {
                    textOverflow: null
                }
            },
            title: { text: '' },
            credits: {
                enabled: false
            },
            tooltip: {
                formatter: function () {
                    return '<b>' + this.point.name + ':</b> ' + this.y + '%';
                }
            },
            plotOptions: {
                pie: {
                    allowPointSelect: false,
                    cursor: 'pointer',
                    dataLabels: {
                        enabled: true,
                        format: '<b>{point.y} %</b>',
                        distance: -50,
                    },
                    showInLegend: true,
                     point: {
                        events: {
                            legendItemClick: function () {
                                return false;
                            }
                        }
                    }
                },
                marker: {
                    fillOpacity: 1
                }
            },
            series: [{
                name: 'Sex Percentage',
                colorByPoint: true,
                data: [
                    {
                        name: 'Male',
                        y: sexData.percentMale
                    }, {
                        name: 'Female',
                        y: sexData.percentFemale
                    }
                ]
            }]
         };

         sexTotalPercentage < 100 && vm.sexChartConfig.series[0].data.push({
            name: 'No Answer',
            y: 100 - sexTotalPercentage
        });
    }

    prepareRaceEthnicityChart(raceEthnicityData) {
        let vm = this;

        let chartWidth = [400, 500, 600, 700, 800];
        let bubbleRadiusMax = [38, 50, 68, 80, 90];
        let bubbleRadiusMin = [20, 20, 20, 20, 20];

        let bubblePointer = 4;

        vm.raceEthnicityChartConfig = {
            chart: {
                type: 'bubble',
                plotBorderWidth: 0,
                zoomType: '',
                width: vm.chartWidthObject.fullChartWidth
            },
            title: {
                text: ''
            },
            credits: {
                enabled: false
            },
            legend: {
                align: 'right',
                verticalAlign: 'middle',
                layout: 'vertical',
                width: vm.chartWidthObject.fullChartLegendWidth,
                itemStyle: {
                    textOverflow: null
                }
            },
            xAxis: {
                gridLineWidth: 0,
                visible: false,
                min: -30,
                max: 100
            },
            yAxis: {
                startOnTick: false,
                endOnTick: false,
                gridLineWidth: 0,
                visible: false,
                min: -30,
                max: 100
            },
            tooltip: {
                useHTML: true,
                headerFormat: '',
                pointFormat: '<b>{point.name}:</b> {point.z}% ',
                followPointer: true
            },
            plotOptions: {
                series: {
                    colors: ['#035BAC', '#3E9EC5', '#E86560', '#E78238', '#FBD44A', '#6CC24A', '#CD453B'],
                    dataLabels: {
                        enabled: true,
                        format: '{point.z}%'
                    },
                    marker: {
                        fillOpacity: 1
                    },
                    events: {
                        legendItemClick: function () {
                            return false;
                        }
                    }
                },
                bubble: {
                    minSize: bubbleRadiusMin[bubblePointer],
                    maxSize: bubbleRadiusMax[bubblePointer]
                }
            },
            series: [
                {
                    name: 'Hispanic/Latino',
                    data: [
                        {
                            x: 10,
                            y: 40,
                            z: raceEthnicityData.percentRaceHisp,
                            name: 'Hispanic/Latino'
                        }
                    ]
                },
                 {
                    name: 'American Indian or Alaska Native',
                    data: [
                       {
                            x: 20,
                            y: 10,
                            z: raceEthnicityData.percentRaceAmericInd,
                            name: 'American Indian or Alaska Native'
                        }
                    ]
                },
                 {
                    name: 'Asian',
                    data: [
                        {
                            x: 30,
                            y: 40,
                            z: raceEthnicityData.percentRaceAsian,
                            name: 'Asian'
                        }
                    ]
                },
                {
                    name: 'Black or African American',
                    data: [
                        {
                            x: 40,
                            y: 10,
                            z: raceEthnicityData.percentRaceAfricAmeric,
                            name: 'Black or African American'
                        }
                    ]
                },
                {
                    name: 'Native Hawaiian or Other Pacific Islander',
                    data: [
                        {
                            x: 50,
                            y: 40,
                            z: raceEthnicityData.percentRaceNatHawaii,
                            name: 'Native Hawaiian or Other Pacific Islander'
                        }
                    ]
                },
                {
                    name: 'White',
                    data: [
                        {
                            x: 60,
                            y: 10,
                            z: raceEthnicityData.percentRaceWhite,
                            name: 'White'
                        }
                    ]
                },
                {
                    name: 'Other',
                    data: [
                        {
                            x: 70,
                            y: 40,
                            z: raceEthnicityData.percentRaceOther,
                            name: 'Other'
                        }
                    ]
                }
            ]
        }
    }

    preparePriorExpChart(prioExpData) {
        let vm = this;
        vm.usmdHonorExpChart = vm.getHonorSocietyChart(prioExpData.mdPercentHonSoc);
        vm.otherHonorExpChart = vm.getHonorSocietyChart(prioExpData.othPercentHonSoc);
    }

    getHonorSocietyChart(chartData) {
        let seriesData = [
            { y: chartData },
            { y: 100 - chartData, color: "#DEEBF7" }
        ];

        let config = {
            chart: {
                plotBorderWidth: 0,
                width: 150,
                height: 150
            },
            title: {
                align: 'center',
                style: {
                    color: '#000',
                    fontSize: '14px',
                    fontWeight: 'bold'
                },
                text: `${seriesData[0].y} %`,
                verticalAlign: 'middle',
                y: 5
            },
            credits: {
                enabled: false
            },
            tooltip: {
                enabled: false
            },
            template: 'donut',
            plotOptions: {
                pie: {
                    dataLabels: {
                        enabled: false
                    },
                    center: ['50%', '50%']
                },
                marker: {
                    fillOpacity: 1
                },
                events: {
                    legendItemClick: function () {
                        return false;
                    }
                }
            },
            series: [{
                type: 'pie',
                name: '',
                innerSize: '80%',
                pointPadding: 0,
			    groupPadding: 0,
                data: seriesData
            }]
        };

        return config;
    }

    getNumberArray(num) {
        return num ? new Array(num) : [];
    }

    prepareResidentsTable(medSchoolData) {
        let vm = this;
        vm.medSchoolNames = medSchoolData;
    }

    prepareCareerPlans(careerGradData) {
        let vm = this;
        vm.careerGradPlansData = careerGradData;
    }


    showHideInternationalSchools() {
        let vm = this;

        if(vm.programData.characteristics && vm.programData.characteristics.resMedSchools) {
            let schoolList = angular.copy(vm.programData.characteristics.resMedSchools);

            vm.medSchoolNames = schoolList.filter((schoolObj) => {
                if(vm.medicalSchoolDisplayConfig.isInternationalSchoolDisabled && vm.medicalSchoolDisplayConfig.isAmericanSchoolDisabled) {
                    return false;
                } else if(vm.medicalSchoolDisplayConfig.isInternationalSchoolDisabled) {
                    return schoolObj.usSchoolInd === 'Y';
                } else if(vm.medicalSchoolDisplayConfig.isAmericanSchoolDisabled){
                    return schoolObj.usSchoolInd === 'N';
                } else {
                    return true;
                }
            });
        }
    }

    loadMap(dataObj) {
        let vm = this;
        let latitude = parseFloat(dataObj.latLong.latitude);
        let longitude = parseFloat(dataObj.latLong.longitude);

        let place = {lat: latitude, lng: longitude};

        vm.GoogleMapsLoader.load(function(google) {
            let map = new google.maps.Map(document.getElementById('program-map'), {
                            zoom: 10,
                            center: place

                        });
             let marker = new google.maps.Marker({
                            position: place,
                            map: map
                        });
        });
    }

    isCareerGrduatePlanEmpty(dataObj) {
        let vm = this;
        if(dataObj) {
            let keyArr = Object.keys(dataObj);

            for(let i=0; i<keyArr.length; i++) {
                if(dataObj[keyArr[i]]) {
                    return false;
                }
            }
        }
        
        return true;
    }

    scrollToTop() {
        window.scrollTo(0, 0);
    }

    $onDestroy() {
        let vm = this;
        vm.secondaryNavbarService.programName = null;
    }
}

const ProgramDetailsComponent = {
    template,
    bindings: {
        programData: '<'
    },
    controller: ProgramDetailsController,
    controllerAs: 'programDetails'
};

export default ProgramDetailsComponent;
