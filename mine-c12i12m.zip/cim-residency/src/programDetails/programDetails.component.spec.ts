import * as angular from 'angular';
import 'angular-mocks/angular-mocks';
import { expect } from 'chai';

describe('ProgramDetailsController', () => {
  it('should be true', () => {
    expect(true).to.equal(true);
  });
});
