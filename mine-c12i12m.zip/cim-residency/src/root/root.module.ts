import {module} from 'angular';
import RootComponent from './root.component';

let RootModule = module('cim.root', [])

// .config(function ($stateProvider, $urlRouterProvider) {
//     $stateProvider.state({
//         name:'home',
//         url: "/",
//         template: '',
//     });

//     $urlRouterProvider.otherwise("/residency-search");
// })

.component('cimRoot', RootComponent);

export default RootModule;
