import template from './root.component.html';
import spinner from './spinner.html';

export class RootController {
  public title: string = 'asdf';
  public scrollToTop: any;
  private $stateObj: any;
  
  constructor($scope, $rootScope, $modal, $anchorScroll, toaster, $state, private secondaryNavbarService, private APP_CONFIG) {
    toaster.pop('info', "title", "text");
    this.$stateObj = $state;
    this.secondaryNavbarService = secondaryNavbarService;
    this.APP_CONFIG = APP_CONFIG;
    
    $scope.$watch(() => $rootScope.loading, function (nv) {
      if (nv === true) {
        $scope.$modal = $modal({
          $scope: $scope,
          template: spinner,
          backdrop: 'static',
          size: 'lg'
        });
      } else {
        if ($scope.$modal) {
          $scope.$modal.hide();
        }
      }
    });

    this.scrollToTop = function () {
      //$window.scrollTo(0, 0);
      $anchorScroll();
    };

    // ===== Scroll to Top ==== Need to convert this function to angular
    $(window).scroll(function () {
      if ($(this).scrollTop() >= 50) {        // If page is scrolled more than 50px
        $('#return-to-top').fadeIn(200);    // Fade in the arrow
      } else {
        $('#return-to-top').fadeOut(200);   // Else fade out the arrow
      }
    });
  }



  // scrollToTop(){
    
  // }
}

let RootComponent = {
  template,
  controller: RootController,
  controllerAs: "root"
};

export default RootComponent;
