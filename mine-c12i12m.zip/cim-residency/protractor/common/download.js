var fs = require('fs');
var path = require('path');

function checkDir() {
    return fs.readdirSync(path.join(__dirname, "../downloads"));
}

function fileDiff(oldFiles, newFiles) {
    for (var i = 0; i < newFiles.length; i++) {
        if (oldFiles.indexOf(newFiles[i]) === -1) {
            return newFiles[i];
        }
    }
}

function waitForFile(oldFiles) {
    return browser.driver.wait(function () {
        // Wait until the file has been downloaded.
        // We need to wait thus as otherwise protractor has a nasty habit of
        // trying to do any following tests while the file is still being
        // downloaded and hasn't been moved to its final location.
        var newFiles = checkDir();
        if (newFiles.length !== oldFiles.length) {
            var file = fileDiff(oldFiles, newFiles);
            if (file.indexOf('.tmp') === -1 && file.indexOf('.crdownload') === -1) {
                console.log('Downloaded: ' + file);
                return true;
            } else {
                return false;
            }
        } else {
            return false;
        }
        // return fs.existsSync(filename);
    }, 30000);
}

module.exports = {
    checkDir: checkDir,
    fileDiff: fileDiff,
    waitForFile: waitForFile
};