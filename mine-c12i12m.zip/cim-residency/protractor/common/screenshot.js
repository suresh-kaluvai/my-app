var fs = require('fs');

afterEach(function () {
    var originalAddExpectationResult = jasmine.Spec.prototype.addExpectationResult;
    jasmine.Spec.prototype.addExpectationResult = function () {
        if (!arguments[0]) {
            var filename = this.description;
            browser.takeScreenshot().then(function (png) {
                var stream = fs.createWriteStream("./protractor/screenshots/" + filename + ".png");
                stream.write(new Buffer(png, 'base64'));
                stream.end();
            });
            // this.description and arguments[1].message can be useful to constructing the filename.
        }
        return originalAddExpectationResult.apply(this, arguments);
    };
});