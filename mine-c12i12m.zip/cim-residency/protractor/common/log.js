afterEach(function () {
    browser.manage().logs().get('browser').then(function (browserLog) {
        expect(browserLog.length).toEqual(0);
        if (browserLog.length > 0) {
            console.log('log: ' + require('util').inspect(browserLog));
        }
    });
});