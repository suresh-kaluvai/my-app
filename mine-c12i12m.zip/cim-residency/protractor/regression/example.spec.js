var navbarMock = require('./mocks/navbar.mock.js'),
    securityMock = require('./mocks/security.mock.js'),
    users = require('./mocks/users.js');

describe('example test', function () {
    beforeAll(function () {
        browser.addMockModule('mocks.navbar', navbarMock);
        browser.addMockModule('mocks.security', securityMock, users.adminComm);
    });
    beforeAll(function () {
        browser.get('https://localhost:4200/');
    });

    require('../common/screenshot.js');

    require('../common/log.js');

    it('do something', function () {
        expect(true).toEqual(true);
    });
});
