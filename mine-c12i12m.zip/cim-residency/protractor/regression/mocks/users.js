module.exports = {
    adminComm: {
        "username": "PLOWMAN",
        "authorities": [{
            "institutionId": "0",
            "groupId": "0",
            "authority": "ERAS COMMUNICATIONS"
        }, {
            "institutionId": "0",
            "groupId": "0",
            "authority": "ERAS STAFF ADMIN"
        }],
        "accountNonExpired": true,
        "accountNonLocked": true,
        "credentialsNonExpired": true,
        "enabled": true,
        "aamcId": 71076411,
        "emailAddress": "plowman@aamc.org",
        "failedLoginCount": 0,
        "givenName": "ss",
        "wamId": "5058645479",
        "commonName": "ss s",
        "surname": "s",
        "status": "A",
        "accountLevel": "2",
        "aamcTempPasswordInd": "N",
        "appCode": "ERAS-STAFF-TOOL",
        "initials": "m",
        "suffix": "",
        "aamcVerificationCd": "VERIFIED",
        "aamcFirstConsentDate": null,
        "aamcLastConsentDate": null,
        "payload": {},
        "contextToken": -1793527919
    }
};