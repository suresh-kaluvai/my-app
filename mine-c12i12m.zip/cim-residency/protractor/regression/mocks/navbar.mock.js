module.exports = function() {
    angular.module('mocks.navbar', [])
        .controller('navController', ['$scope', '$q',
            function($scope, $q) {
                $scope.isAuthenticated = function() {
                    $q.when(true);
                };
            }
        ]);
};