module.exports = function() {
    var args = arguments;
    angular.module('mocks.security', [])
        .provider('SSOSecurity', function() {
            var config = {
                'openSsoUrl': {
                    'authContext': '/30/auth-service',
                    'authServlet': '/services-rs/authentication',
                    'validate': '/isTokenValid',
                    'attributes': '/attributes'
                },
                'loginTbarTemplatePath': '/security/src/tpl/login-tbar-links-tpl.html',
                'loginTbarController': 'defaultLoginTbarController'
            };

            return {
                getAuthenticatedUser: ['SSOSecurity',
                    function(SSOSecurity) {
                        return SSOSecurity.getAuthenticatedUser();
                    }
                ],

                $get: ['$http', '$q',
                    function($http, $q) {

                        var self = this;
                        self.context = args[0];
                        self.lastAccessed = 0;
                        self.retryQueue = [];

                        var service = {
                            getContext: function() {
                                return self.context;
                            },

                            login: function() {
                                login.login();
                            },

                            logout: function() {
                                self.context = {};
                                login.logout();
                            },

                            isAuthenticated: function() {
                                return !_.isEmpty(self.context);
                            },

                            hasAnyAuthority: function(authoritiesToCheck) {
                                var authorities = _.map(self.context.authorities, 'authority');

                                if (typeof authoritiesToCheck === 'string') {
                                    authoritiesToCheck = authoritiesToCheck.split(',');
                                }
                                return _.intersection(authorities, authoritiesToCheck).length > 0;
                            },

                            getAuthenticatedUser: function() {
                                return $q.when(self.context);
                            },

                            isUserLoggedIn: function() {
                                return;
                            },

                            retryFailedLogin: function() {
                                return;
                            },

                            getRetryLength: function() {
                                return self.retryQueue.length;
                            },

                            getLastAccessed: function() {
                                return self.lastAccessed;
                            }
                        };
                        return service;
                    }
                ]
            };
        });
};
