module.exports = {
    login: {
        userName: 'ecfmg_1',
        password: '123qwe!',
        urlTest: /account\/#\/login\?gotoUrl=https:%2F%2Fapps.ftest.aamc.org%2Feras-stafftools-web%2F%23%2Fapplicationsearch&allowInternal=false/,
        url: 'https://apps.ftest.aamc.org/eras-stafftools-web/'
    }
};