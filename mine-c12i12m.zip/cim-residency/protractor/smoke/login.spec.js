var login = browser.params.config.login;

describe(browser.params.env + ' login', function () {
    var loggedIn = false;
    beforeAll(function () {
        browser.get(login.url);
        browser.driver.wait(function () {
            return browser.driver.getCurrentUrl().then(function (url) {
                return (login.urlTest).test(url);
            });
        });

        // Login using valid Staff tools credentials.
        element(by.model('login.username')).sendKeys(login.userName);
        element(by.model('login.password')).sendKeys(login.password);
        element(by.xpath('//button[@ng-click="validateNow=true"]')).click();
        browser.driver.wait(function () {
            return browser.driver.getCurrentUrl().then(function (url) {
                if ((/eras-stafftools-web\/#\/applicationsearch/).test(url)) {
                    loggedIn = true;
                    return true;
                } else {
                    return false;
                }
            });
        });
        browser.sleep(1000);
    });

    it('should login and clear the logs', function () {
        browser.manage().logs().get('browser').then(function (browserLog) {
            // console.log('first test log: ' + require('util').inspect(browserLog));
        });
    });
});