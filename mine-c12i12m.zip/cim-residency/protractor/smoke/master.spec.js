var path = require('path');

exports.config = {
    seleniumAddress: 'http://localhost:4444/wd/hub',
    onPrepare: function() {
        if (browser.params.env === 'ftest') {
            browser.params.config = require('./ftest.js');
        }
    },
    specs: [
        './login.spec.js'
    ],
    capabilities: {
        'browserName': 'chrome',
        'chromeOptions': {
            // Get rid of --ignore-certificate yellow warning
            args: ['--no-sandbox', '--test-type=browser'],
            // Set download path and avoid prompting for download even though
            // this is already the default on Chrome but for completeness
            prefs: {
                'download': {
                    prompt_for_download: false,
                    directory_upgrade: true,
                    default_directory: path.join(__dirname, "downloads")
                }
            }
        }
    }
};