const path = require('path');
const {
  CommonsChunkPlugin
} = require('webpack').optimize;
const rules = require('./rules.js');
const HtmlWebpackPlugin = require('html-webpack-plugin');
const nodeModules = path.join(process.cwd(), 'node_modules');
const entryPoints = ["inline", "polyfills", "sw-register", "styles", "vendor", "main"];
const minimizeCss = false;
const os = require('os');

module.exports = function () {
  return {
    rules: rules,
    host: os.hostname().toLowerCase() + ".adm.aamc.org",
    externals: {},
    entry: {
      "main": [
        "./src/main.ts"
      ],
      "polyfills": [
        "./src/polyfills.ts"
      ],
      "styles": [
        "./src/styles.scss"
      ]
    },
    plugins: [
      new HtmlWebpackPlugin({
        "template": "./src/index.html",
        "filename": "./index.html",
        "baseUrl": '/',
        "hash": false,
        "inject": true,
        "compile": true,
        "favicon": false,
        "minify": false,
        "cache": true,
        "showErrors": true,
        "chunks": "all",
        "excludeChunks": [],
        "title": "Webpack App",
        "xhtml": true,
        "chunksSortMode": function sort(left, right) {
          let leftIndex = entryPoints.indexOf(left.names[0]);
          let rightindex = entryPoints.indexOf(right.names[0]);
          if (leftIndex > rightindex) {
            return 1;
          } else if (leftIndex < rightindex) {
            return -1;
          } else {
            return 0;
          }
        }
      }),
      new CommonsChunkPlugin({
        "name": "inline",
        "minChunks": null
      }),
      new CommonsChunkPlugin({
        "name": "vendor",
        "minChunks": (module) => module.resource && module.resource.startsWith(nodeModules),
        "chunks": [
          "main"
        ]
      })
    ],

    proxy: [{
      context: ['/30/**', '/referenceDataService/**', '/event-log-service/**'],
      target: 'https://apps.development.aamc.org',
      secure: false,
      logLevel: 'debug',
      changeOrigin: true
    }, {
      context: ['/openam/**', '/auth-service/**'],
      target: 'https://apps.development.aamc.org',
      secure: false,
      logLevel: 'debug',
      changeOrigin: true
    }],

    output: {
      "path": path.join(process.cwd(), "dev"),
      "filename": "[name].bundle.js",
      "chunkFilename": "[id].chunk.js"
    },

    setup: function() {},

    disableHostCheck: true
  };
};
