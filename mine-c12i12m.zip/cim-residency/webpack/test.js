const path = require('path');
const {
  CommonsChunkPlugin
} = require('webpack').optimize;
const rules = require('./rules.js');
const HtmlWebpackPlugin = require('html-webpack-plugin');
const nodeModules = path.join(process.cwd(), 'node_modules');
const entryPoints = ["inline", "polyfills", "sw-register", "styles", "vendor", "main"];
const minimizeCss = false;
const os = require('os');

module.exports = function () {
  return {
    rules: [{
        test: /\.ts(x?)$/,
        include: [/src/, /node_modules/, /__tests__/],
        use: 'ts-loader'
      },
      {
        test: /\.js$/,
        use: 'babel-loader',
        exclude: /node_modules/
      },
      {
        test: /\.html$/,
        use: 'raw-loader'
      },
      {
        test: /\.(less|css|sass|png|jpg|jpeg|gif|svg|woff|woff2|ttf|eot)$/,
        use: 'ignore-loader'
      },
      {
        test: /\.js$/,
        exclude: [
          /mocks/,
          /__tests__/,
          /node_modules/,
          /\.spec\.js$/
        ],
        use: 'isparta-loader'
      },
      {
        test: /\.ts$/,
        loader: 'istanbul-instrumenter-loader',
        enforce: 'post',
        exclude: [
          'node_modules',
          /\.spec\.ts$/
        ]
      }, {
        test: /\.md$/,
        use: [{
            loader: "html-loader?exportAsEs6Default"
          },
          {
            loader: "markdown-loader",
            options: {
              /* your options here */
            }
          }
        ]
      }
    ],
    host: os.hostname().toLowerCase() + ".adm.aamc.org",
    externals: {},
    entry: {
      "test": [
        "./src/test.ts"
      ]
    },
    plugins: [],

    proxy: {},

    output: {
      "path": path.join(process.cwd(), "dev"),
      "filename": "[name].bundle.js",
      "chunkFilename": "[id].chunk.js"
    },

    setup: function () {},

    disableHostCheck: false
  };
};