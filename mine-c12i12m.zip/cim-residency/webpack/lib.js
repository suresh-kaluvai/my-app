const path = require('path');
const rules = require('./rules.lib');
const {
  UglifyJsPlugin
} = require('webpack').optimize;
const { WebpackBundleSizeAnalyzerPlugin } = require('webpack-bundle-size-analyzer');
const fs = require('fs');
const packageJson = JSON.parse(fs.readFileSync(path.join(process.cwd(), 'package.json'), 'utf8'));


module.exports = function () {
  return {
    rules: rules,
    host: 'localhost',
    entry: {
      "main": [
        "./src-lib/main.ts"
      ]
    },

    externals: {
        angular: true,
        jquery: '$',
        'core-js': true,
        rxjs: true,
        'zone.js': true
    },

    plugins: [
      new UglifyJsPlugin({ minimize: true }),
      new WebpackBundleSizeAnalyzerPlugin('../lib-report.txt')
    ],

    proxy: {},

    output: {
      path: path.join(process.cwd(), "lib"),
      filename: 'main.' + packageJson.version + '.js',
      library: packageJson.name,
      libraryTarget: 'umd'
    },

    setup: function(){},

    disableHostCheck: false
  };
};
