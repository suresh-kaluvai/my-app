const path = require('path');
const {
  CommonsChunkPlugin
} = require('webpack').optimize;
const rules = require('./rules.js');
const HtmlWebpackPlugin = require('html-webpack-plugin');
const nodeModules = path.join(process.cwd(), 'node_modules');
const entryPoints = ["inline", "polyfills", "sw-register", "styles", "vendor", "main"];
const minimizeCss = false;

module.exports = function () {
  return {
    rules: rules,
    host: 'localhost',
    externals: {},
    entry: {
      "main": [
        "./src/main.ts"
      ],
      "polyfills": [
        "./src/polyfills.ts"
      ],
      "styles": [
        "./src/styles.scss"
      ]
    },
    plugins: [
      new HtmlWebpackPlugin({
        "template": "./src/index.html",
        "filename": "./index.html",
        "baseUrl": '/',
        "hash": false,
        "inject": true,
        "compile": true,
        "favicon": false,
        "minify": false,
        "cache": true,
        "showErrors": true,
        "chunks": "all",
        "excludeChunks": [],
        "title": "Webpack App",
        "xhtml": true,
        "chunksSortMode": function sort(left, right) {
          let leftIndex = entryPoints.indexOf(left.names[0]);
          let rightindex = entryPoints.indexOf(right.names[0]);
          if (leftIndex > rightindex) {
            return 1;
          } else if (leftIndex < rightindex) {
            return -1;
          } else {
            return 0;
          }
        }
      }),
      new CommonsChunkPlugin({
        "name": "inline",
        "minChunks": null
      }),
      new CommonsChunkPlugin({
        "name": "vendor",
        "minChunks": (module) => module.resource && module.resource.startsWith(nodeModules),
        "chunks": [
          "main"
        ]
      })
    ],

    proxy: {},

    output: {
      "path": path.join(process.cwd(), "dev"),
      "filename": "[name].bundle.js",
      "chunkFilename": "[id].chunk.js"
    },

    setup: function(app) {
        app.get('/30/config-service/services-rs/config/*', function(req, res, next) {
            console.log(req);
            res.setHeader("Content-Type", "application/json");
                        res.end(JSON.stringify({
                            "DWS_SERVICE_URL": "30/eras-dws-service",
                            "LOG_SERVICE_URL": "https://localhost/log-service/log",
                            "AAMC_HEADER_LOGO": "https://static.localhost/content/images/aamcLogoSmWht.png",
                            "EVENTLOG_SERVICE_URL": "/event-log-service",
                            "ENV": "localhost",
                            "SERVICE_URL": "30/eras-restful-services",
                            "PAYPAL_URL": "https://pilot-payflowlink.paypal.com",
                            "APP_CODE": "ERAS-STAFF-TOOL",
                            "UAM_URL": "30/userAccountMgt",
                            "DOC_SERVICE_URL": "30/eras-dws-doc-service",
                            "APPLICATION_SERVICE_URL": "eras-application-service",
                            "LOGOUT_URL": "https://localhost/account/#/logout",
                            "SERVICES_URL": "https://services.localhost",
                            "PAYPAL_MODE": "test",
                            "ISERVICES_URL": "https://iservices.localhost",
                            "REF_DATA_URL": "/referenceDataService/services-rs/refdata",
                            "AUTH_SERVICE_URL": "https://localhost/auth-service",
                            "LOGIN_URL": "https://localhost/account/#/login",
                            "SEND_LOGS": "false",
                            "ACCOUNT_MANAGER_URL": "https://localhost/account/#/manage/options",
                            "OPENAM_BASE_URL": "/openam",
                            "DEBUG": "true",
                            "PAYPAL_REDIRECT": "https://localhost/payment-redirect",
                            "CURRENT_SEASON": "2016",
                            "TEST": "2016",
                            "PAYPAL_TIMEOUT": "30000",
                            "BASE_URL": "https://localhost",
                            "CBRVIEW_URL": "cbrview/index.cfm"
                        }));
                        next();
        });
    },

    disableHostCheck: false
  };
};
