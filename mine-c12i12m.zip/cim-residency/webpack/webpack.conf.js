const path = require('path');
const ProgressPlugin = require('webpack/lib/ProgressPlugin');
const HtmlWebpackPlugin = require('html-webpack-plugin');
const ExtractTextPlugin = require('extract-text-webpack-plugin');
const autoprefixer = require('autoprefixer');
const postcssUrl = require('postcss-url');
const cssnano = require('cssnano');
const os = require('os');

const {
  ProvidePlugin
} = require('webpack');
const {
  CommonsChunkPlugin,
  ModuleConcatenationPlugin
} = require('webpack').optimize;

module.exports = function (env = {}) {
  let {
    entry,
    plugins,
    output,
    proxy,
    rules,
    externals,
    setup,
    host,
    disableHostCheck
  } = require('./' + env.mode + '.js')(env);

  return {
    "devtool": "eval",
    resolve: {
      modules: [
        path.join(__dirname, "src"),
        'node_modules'
      ],
      extensions: ['.ts', '.js', '.json', '.md']
    },
    "entry": entry,
    "output": output,
    "module": {
      "rules": rules
    },
    "plugins": [
      new ProvidePlugin({
        $: "jquery",
        jQuery: "jquery",
        "window.jQuery": "jquery"
      }),
      new ModuleConcatenationPlugin(),
      new ProgressPlugin(),
      ...plugins,
      new ExtractTextPlugin({
        "filename": "[name].bundle.css",
        "disable": true
      }),
    ],
    externals: externals,
    node: {
      fs: "empty",
      global: true,
      crypto: "empty",
      tls: "empty",
      net: "empty",
      process: true,
      module: false,
      clearImmediate: false,
      setImmediate: false
    },
    devServer: {
      historyApiFallback: true,
      https: true,
      host,
      disableHostCheck,
      proxy,
      setup
    }
  };
};