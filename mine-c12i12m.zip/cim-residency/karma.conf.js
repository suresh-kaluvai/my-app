// Karma configuration file, see link for more information
// https://karma-runner.github.io/0.13/config/configuration-file.html

var path = require('path');
var webpackConfig = require('./webpack/webpack.conf.js')({
  mode: 'test'
});

module.exports = function (config) {
  config.set({
    base: __dirname,
    frameworks: ['mocha', 'chai', 'sinon', 'chai-as-promised'],
    plugins: [
      require('karma-mocha'),
      require('karma-chai'),
      require('karma-chai-plugins'),
      require('karma-chrome-launcher'),
      require("karma-sinon"),
      require("karma-coverage"),
      require("karma-sourcemap-loader"),
      require("karma-phantomjs-launcher"),
      require("karma-junit-reporter"),
      require("karma-html-reporter"),
      require("karma-webpack")
    ],
    client: {
      captureConsole: true,
      chai: {
        includeStack: true
      },
      mocha: {
        reporter: 'html',
        ui: 'bdd'
      },
      clearContext: false // leave Jasmine Spec Runner output visible in browser
    },
    files: [{
      pattern: './src/test.ts',
      watched: false
    }],
    preprocessors: {
      // add webpack as preprocessor
      'src/test.ts': ['webpack', 'sourcemap'],
      'src/*.ts': ['webpack', 'sourcemap'],
      'src/*.js': ['webpack', 'sourcemap'],
      'src/**/*.ts': ['webpack', 'sourcemap'],
      'src/**/*.js': ['webpack', 'sourcemap']
    },
    webpack: webpackConfig,
    webpackMiddleware: {
      // webpack-dev-middleware configuration
      // i.e.
      noInfo: true,
      // and use stats to turn off verbose output
      stats: {
        // options i.e.
        chunks: false
      }
    },
    mime: {
      'text/x-typescript': ['ts', 'tsx']
    },
    reporters: ['progress', 'coverage', 'junit', 'html'],
    coverageReporter: {
      dir: 'coverage/',
      includeAllSources: true,
      reporters: [{
          type: 'text-summary'
        },
        {
          type: 'html'
        }, {
          type: 'lcovonly',
          subdir: 'report-lcov'
        }
      ]
    },

    htmlReporter: {
      outputDir: 'coverage',
      focusOnFailures: true,
      reportName: 'report'
    },

    junitReporter: {
      outputDir: 'coverage', // results will be saved as $outputDir/$browserName.xml
      outputFile: 'test-results.xml', // if included, results will be saved as $outputDir/$browserName/$outputFile
      useBrowserName: false // add browser name to report and classes names
    },
    port: 9876,
    colors: true,
    logLevel: config.LOG_INFO,
    autoWatch: true,
    browsers: ['PhantomJS'],
    singleRun: true
  });
};