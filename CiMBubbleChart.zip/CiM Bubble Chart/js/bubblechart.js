
/*
 *   CONSTRAINT: The chart should not go below 400px otherwise it will not render properly.
 *   
 *   IMPLEMENTATION NOTES: This is set up by having predefined X and Y coordinates for each point. 
 *   The changing variables are going to be the chart width and the Min and Max radius of the bubbles. 
 *
 *   Bubble
 *   ------
 *   The bubble min radius will always be the same. 
 *   The bubble max radius will be a changing value based on the chart width. 
 *
 *   Chart
 *   -----
 *   The chart will have 5 predetermined widths which will need to be used depending on the size of the container.  
 *   The chart should just be positioned in the center of the container. 
 *   The width of the chart should be less than the width of the container. Some logic will need to be implemented to check for that.
 *   
 */

var chartWidth = [400, 500, 600, 700, 800]; 
var bubbleRadiusMax = [38, 50, 68, 80, 90];
var bubbleRadiusMin = [20, 20, 20, 20, 20];

var bubblePointer = 4;

Highcharts.chart('container', {
    chart: {
        type: 'bubble',
        plotBorderWidth: 0,
        zoomType: '',
        width: chartWidth[bubblePointer]
    },
    exporting: {
        enabled: false
    },  
    title: {
        text: ''
    },
    legend: {
        align: 'right',
        verticalAlign: 'middle',
        layout: 'vertical',
        width: 100,
        itemStyle: {
            textOverflow: null
        }
    },
    xAxis: {
        gridLineWidth: 0,
        visible: false,
        min: -30,
        max: 100
    },
    yAxis: {
        startOnTick: false,
        endOnTick: false,
        gridLineWidth: 0,
        visible: false,
        min: -30,
        max: 100
    },
    tooltip: {
        useHTML: true,
        headerFormat: '',
        pointFormat: '<b>{point.name}:</b> {point.z}% ',
        followPointer: true
    },
    plotOptions: {
        series: {
            colors: ['#035BAC', '#3E9EC5', '#E86560', '#E78238', '#FBD44A', '#6CC24A', '#CD453B'],
            dataLabels: {
                enabled: true,
                format: '{point.z}%'
            },
            marker: {
                fillOpacity: 1
            }
        },
        bubble: {
            minSize: bubbleRadiusMin[bubblePointer],
            maxSize: bubbleRadiusMax[bubblePointer]
        }
    },
    series: [
        {
            name: 'Hispanic/Latino',
            data: [
                { 
                    x: 10, 
                    y: 40, 
                    z: 100,
                    name: 'Hispanic/Latino'
                }
            ]
        },
         {
            name: 'American Indian or Alaska Native',
            data: [
               { 
                    x: 20, 
                    y: 10,
                    z: 0,
                    name: 'American Indian or Alaska Native'
                }
            ]
        },
         {
            name: 'Asian',
            data: [
                { 
                    x: 30, 
                    y: 40,
                    z: 100,
                    name: 'Asian'
                }
            ]
        },
        {
            name: 'Black or African American',
            data: [
                { 
                    x: 40, 
                    y: 10,
                    z: 100,
                    name: 'Black or African American'
                }
            ]
        },
        {
            name: 'Native Hawaiian or Other Pacific Islander',
            data: [
                { 
                    x: 50, 
                    y: 40,
                    z: 100,
                    name: 'Native Hawaiian or Other Pacific Islander'
                }
            ]
        },
        {
            name: 'White',
            data: [
                { 
                    x: 60, 
                    y: 10,
                    z: 100,
                    name: 'White'
                }
            ]
        },
        {
            name: 'Other',
            data: [
                { 
                    x: 70, 
                    y: 40,
                    z: 100,
                    name: 'Other'
                }
            ]
        }
    ]
});